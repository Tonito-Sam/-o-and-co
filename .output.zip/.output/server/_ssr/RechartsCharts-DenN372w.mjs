import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { _ as Cell, a as LineChart, b as Legend, f as Radar, g as PolarGrid, h as PolarRadiusAxis, l as Line, m as PolarAngleAxis, n as RadarChart, o as YAxis, p as Pie, r as PieChart, s as XAxis, u as CartesianGrid, v as ResponsiveContainer, y as Tooltip } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/RechartsCharts-DenN372w.js
var import_jsx_runtime = require_jsx_runtime();
function RechartsCharts({ channels, colors, radar, revenueTrend }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid lg:grid-cols-3 gap-4 mb-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "card-soft p-5 lg:col-span-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-display font-semibold mb-3",
				children: "Revenue forecast — 12 months"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-72",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LineChart, {
					data: revenueTrend,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
							strokeDasharray: "3 3",
							stroke: "oklch(0.92 0.008 95)"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
							dataKey: "month",
							tick: { fontSize: 11 },
							axisLine: false,
							tickLine: false
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
							tick: { fontSize: 11 },
							axisLine: false,
							tickLine: false
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
							borderRadius: 10,
							fontSize: 12
						} }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
							type: "monotone",
							dataKey: "target",
							stroke: "oklch(0.78 0 0)",
							strokeDasharray: "4 4"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
							type: "monotone",
							dataKey: "revenue",
							stroke: "oklch(0.5 0.08 195)",
							strokeWidth: 2.5,
							dot: { r: 3 }
						})
					]
				}) })
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "card-soft p-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-display font-semibold mb-3",
				children: "Revenue mix"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-72",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PieChart, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pie, {
					data: channels,
					dataKey: "value",
					nameKey: "name",
					innerRadius: 50,
					outerRadius: 80,
					paddingAngle: 2,
					children: channels.map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { fill: colors[i] }, i))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, {
					iconSize: 8,
					wrapperStyle: { fontSize: 11 }
				})] }) })
			})]
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid lg:grid-cols-3 gap-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "card-soft p-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-display font-semibold mb-3",
				children: "Top performer (Sandton) vs group avg"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-64",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(RadarChart, {
					data: radar,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarGrid, { stroke: "oklch(0.92 0.008 95)" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarAngleAxis, {
							dataKey: "metric",
							tick: { fontSize: 11 }
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarRadiusAxis, {
							tick: false,
							axisLine: false
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radar, {
							dataKey: "A",
							stroke: "oklch(0.5 0.08 195)",
							fill: "oklch(0.5 0.08 195)",
							fillOpacity: .3
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radar, {
							dataKey: "B",
							stroke: "oklch(0.55 0.1 30)",
							fill: "oklch(0.55 0.1 30)",
							fillOpacity: .15
						})
					]
				}) })
			})]
		})
	})] });
}
//#endregion
export { RechartsCharts, RechartsCharts as default };
