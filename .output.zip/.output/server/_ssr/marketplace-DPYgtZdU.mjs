import { i as __toESM } from "../_runtime.mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { t as Badge } from "./badge-D1Dupn2y.mjs";
import { n as StatCard, t as PageHeader } from "./PageHeader-BGUb7ose.mjs";
import { L as History, b as RotateCcw, d as Star, m as ShoppingBag, u as Store } from "../_libs/lucide-react.mjs";
import { D as tenantOrderHistory, _ as formatZAR, b as marketplace, n as ROLES } from "./mock-B_SZb7O5.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as useRole } from "./role-context-CF0HzSPT.mjs";
import { i as TabsTrigger, n as TabsContent, r as TabsList, t as Tabs } from "./tabs-CCJRliUM.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-C0WYWEQX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/marketplace-DPYgtZdU.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function tenantBranchFor(roleId) {
	return (ROLES.find((x) => x.id === roleId)?.scope.match(/(Bryanston|Kyalami|Rosebank|Union Station)/))?.[1] ?? "Bryanston";
}
var STATUS_TONE = {
	Queued: "bg-muted text-foreground/70",
	Preparing: "bg-warning/15 text-warning border-warning/30",
	Ready: "bg-brand/15 text-brand border-brand/30",
	Shipped: "bg-brand/15 text-brand border-brand/30",
	Delivered: "bg-success/15 text-success border-success/30",
	Collected: "bg-success/15 text-success border-success/30"
};
function Marketplace() {
	const { role } = useRole();
	const isTenant = role.id === "tenant-admin";
	const branch = tenantBranchFor(role.id);
	const [tab, setTab] = (0, import_react.useState)(isTenant ? "shop" : "shop");
	const [cat, setCat] = (0, import_react.useState)("All");
	const cats = ["All", ...Array.from(new Set(marketplace.map((m) => m.category)))];
	const items = marketplace.filter((m) => cat === "All" || m.category === cat);
	const add = (title) => toast.success(`Added "${title}" to your order — charge to account`);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-[1300px]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				eyebrow: "Marketplace",
				title: "Office & Co Store + Tenant Marketplace",
				description: isTenant ? `Stationery, furniture and services delivered to ${branch}. Review your past orders or reorder in one tap.` : "Stationery, furniture and services from Office & Co, plus offerings from the tenant community.",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					children: "List a product"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 md:grid-cols-4 gap-4 mb-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "GMV (month)",
						value: formatZAR(128e4),
						delta: "▲ 18%",
						accent: "success"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Active listings",
						value: "412"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Tenant sellers",
						value: "38",
						delta: "+5",
						accent: "brand"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Avg rating",
						value: "4.7",
						hint: "↑ from 4.6"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
				value: tab,
				onValueChange: setTab,
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
						className: "flex-wrap h-auto",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
							value: "shop",
							className: "gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Store, { className: "size-3.5" }), "Shop"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
							value: "orders",
							className: "gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { className: "size-3.5" }), "My orders"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
						value: "shop",
						children: [
							isTenant && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-4 flex items-center gap-2 text-xs text-muted-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
									variant: "outline",
									className: "gap-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Store, { className: "size-3" }),
										"Delivering to ",
										branch
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "· Charge-to-account enabled for all Tundra Capital members" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex gap-2 mb-4 flex-wrap",
								children: cats.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: cat === t ? "default" : "outline",
									className: "cursor-pointer",
									onClick: () => setCat(t),
									children: t
								}, t))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4",
								children: items.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "card-soft overflow-hidden hover:shadow-elevated transition-shadow",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-36 bg-gradient-to-br from-accent via-brand-soft to-muted grid place-items-center",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, { className: "size-10 text-brand/60" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-4 flex flex-col h-full",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
												variant: "outline",
												className: "text-[10px] mb-1.5 self-start",
												children: m.category
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "font-medium text-sm leading-tight",
												children: m.title
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "text-[11px] text-muted-foreground mt-1",
												children: ["by ", m.seller]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-3 flex items-center justify-between",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "font-display text-lg font-semibold tabular-nums",
													children: formatZAR(m.price)
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-1 text-xs text-muted-foreground",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "size-3 fill-warning text-warning" }),
														" ",
														m.rating
													]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												size: "sm",
												className: "w-full mt-3",
												onClick: () => add(m.title),
												children: "Add to order"
											})
										]
									})]
								}, m.id))
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "orders",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MyMarketplaceOrders, { branch })
					})
				]
			})
		]
	});
}
function MyMarketplaceOrders({ branch }) {
	const rows = tenantOrderHistory.filter((o) => o.branch === branch && o.kind === "marketplace");
	const reorder = (id) => toast.success(`Reordered ${id} — added to your cart`);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-2 md:grid-cols-4 gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Marketplace orders",
					value: String(rows.length),
					accent: "brand"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Spent (month)",
					value: formatZAR(rows.reduce((s, r) => s + r.total, 0)),
					accent: "success"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Delivering to",
					value: branch
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Preferred method",
					value: "Charge to account"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "card-soft overflow-hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Order" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Items" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Method" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
					className: "text-right",
					children: "Total"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Status" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
					className: "text-right",
					children: "Actions"
				})
			] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableBody, { children: [rows.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-sm font-medium",
					children: o.id
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[11px] text-muted-foreground",
					children: o.placedAt
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-sm",
					children: o.items.map((i) => `${i.qty}× ${i.name}`).join(" · ")
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
					className: "text-xs",
					children: o.method
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
					className: "text-right tabular-nums",
					children: formatZAR(o.total)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					variant: "outline",
					className: STATUS_TONE[o.status],
					children: o.status
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
					className: "text-right",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "outline",
						className: "h-7 gap-1",
						onClick: () => reorder(o.id),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-3" }), "Reorder"]
					})
				})
			] }, o.id)), rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableRow, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
				colSpan: 6,
				className: "text-center text-sm text-muted-foreground py-8",
				children: [
					"No marketplace orders yet at ",
					branch,
					"."
				]
			}) })] })] })
		})]
	});
}
//#endregion
export { Marketplace as component };
