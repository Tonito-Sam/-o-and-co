import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/BrandLogo-Cz5zT1UD.js
var import_jsx_runtime = require_jsx_runtime();
var OCO_Stacked_Logo_White_300px_default = "/p/o&co/assets/OCO-Stacked-Logo-White-300px-HZXkK38G.png";
function BrandLogo(props) {
	const { alt = "Office & Co", ...imgProps } = props;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: OCO_Stacked_Logo_White_300px_default,
		alt,
		...imgProps
	});
}
//#endregion
export { BrandLogo as t };
