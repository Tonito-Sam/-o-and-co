import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { t as Badge } from "./badge-D1Dupn2y.mjs";
import { t as PageHeader } from "./PageHeader-BGUb7ose.mjs";
import { f as Sparkles, o as TriangleAlert, r as Users, s as TrendingUp, ut as Building2, v as Send } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ai-assistant-DJKe3Bmj.js
var import_jsx_runtime = require_jsx_runtime();
var suggestions = [
	{
		icon: TrendingUp,
		text: "Show branch performance for the last quarter"
	},
	{
		icon: Building2,
		text: "Which branch has the highest occupancy?"
	},
	{
		icon: TriangleAlert,
		text: "Which tenants are at risk of churn?"
	},
	{
		icon: Users,
		text: "What is our projected revenue next month?"
	}
];
var conversation = [{
	role: "user",
	text: "Which branch has the highest occupancy this month, and what's driving it?"
}, {
	role: "ai",
	text: "Bryanston leads the group at 92% occupancy — 7 points above group average. Three signals are driving it: (1) Northwind Legal expanded by 8 desks in May, (2) Cape Town tour-to-close rate hit 41% vs group 34%, (3) Wine Down Friday is the most-attended internal event in the group, lifting renewal intent scores by 0.4. Recommended action: replicate the WC events calendar in Kyalami and Rosebank.",
	facts: [
		"Bryanston: 92%",
		"Group avg: 85%",
		"Northwind +8 desks",
		"Tour→Close: 41%"
	]
}];
function AI() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-[1100px]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: "AI & Automation",
			title: "WorkspaceOS Assistant",
			description: "Ask anything about the business — across sales, tenants, facilities, finance and community."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "card-soft p-6 md:p-8 min-h-[60vh] flex flex-col",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex-1 space-y-6",
				children: conversation.map((m, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `flex gap-3 ${m.role === "user" ? "justify-end" : ""}`,
					children: [m.role === "ai" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid size-9 shrink-0 place-items-center rounded-lg bg-gradient-to-br from-brand to-primary text-primary-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `max-w-[80%] rounded-2xl px-4 py-3 ${m.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted/50"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm leading-relaxed",
							children: m.text
						}), m.facts && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 flex flex-wrap gap-1.5",
							children: m.facts.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: "outline",
								className: "text-[10px] bg-card",
								children: f
							}, f))
						})]
					})]
				}, i))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 pt-6 border-t",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[11px] uppercase tracking-wider text-muted-foreground font-medium mb-2",
						children: "Try asking"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid sm:grid-cols-2 gap-2 mb-4",
						children: suggestions.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							className: "flex items-center gap-2 text-left px-3 py-2.5 rounded-lg bg-muted/40 hover:bg-muted text-sm transition-colors",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(s.icon, { className: "size-3.5 text-brand shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate",
								children: s.text
							})]
						}, s.text))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							placeholder: "Ask WorkspaceOS anything…",
							className: "h-12 pr-12 bg-card"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon",
							className: "absolute right-1.5 top-1.5 size-9",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4" })
						})]
					})
				]
			})]
		})]
	});
}
//#endregion
export { AI as component };
