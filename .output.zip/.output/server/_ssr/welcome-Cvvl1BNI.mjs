import { i as __toESM } from "../_runtime.mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { t as Badge } from "./badge-D1Dupn2y.mjs";
import { A as MapPin, I as Landmark, M as LogIn, X as Coffee, at as Check, f as Sparkles, h as ShieldCheck, mt as ArrowRight, nt as ChevronLeft, r as Users, st as Calendar, tt as ChevronRight, ut as Building2 } from "../_libs/lucide-react.mjs";
import { f as demoAccounts, r as branches } from "./mock-B_SZb7O5.mjs";
import { t as BrandLogo } from "./BrandLogo-Cz5zT1UD.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/welcome-Cvvl1BNI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var space_bryanston_default = "/p/o&co/assets/space-bryanston-PTa5Jxpf.jpg";
var space_rosebank_default = "/p/o&co/assets/space-rosebank-DLGX1kDh.jpg";
var space_kyalami_default = "/p/o&co/assets/space-kyalami-BcQdajjm.jpg";
var space_union_station_default = "/p/o&co/assets/space-union-station-Bc5NOarh.jpg";
var slides = [
	{
		img: space_bryanston_default,
		name: "Bryanston",
		tag: "Private offices with a skyline",
		copy: "Golden-hour desks, plants, and a view of Sandton that never gets old.",
		cta: "Tour Bryanston"
	},
	{
		img: space_rosebank_default,
		name: "Rosebank",
		tag: "The lounge for the ambitious",
		copy: "Deep emerald velvet, terrazzo, and a community that ships.",
		cta: "Tour Rosebank"
	},
	{
		img: space_kyalami_default,
		name: "Kyalami",
		tag: "Boardrooms with a horizon",
		copy: "Glass-walled meeting rooms overlooking the rolling Kyalami hills.",
		cta: "Tour Kyalami"
	},
	{
		img: space_union_station_default,
		name: "Union Station",
		tag: "Johannesburg's flagship event venue",
		copy: "A restored heritage building for galas, summits and product launches.",
		cta: "Book Union Station"
	}
];
function Welcome() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteNav, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PortalCTA, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Branches, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UnionStationFeature, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Membership, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Community, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FAQ, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CTA, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
		]
	});
}
function SiteNav() {
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-50 border-b bg-background/85 backdrop-blur-xl",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-4 sm:px-6 h-16 flex items-center justify-between gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/welcome",
					className: "flex items-center gap-2.5 min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid size-9 shrink-0 place-items-center rounded-lg bg-primary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrandLogo, { className: "size-6 object-contain" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "leading-tight min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-display text-sm font-semibold truncate",
							children: "Office & Co"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[10px] text-muted-foreground",
							children: "South Africa"
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "hidden md:flex items-center gap-7 text-sm text-foreground/80",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#branches",
							className: "hover:text-foreground",
							children: "Branches"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#union-station",
							className: "hover:text-foreground",
							children: "Union Station"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#membership",
							className: "hover:text-foreground",
							children: "Membership"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#community",
							className: "hover:text-foreground",
							children: "Community"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "hidden sm:flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "ghost",
						size: "sm",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/auth/sign-in",
							className: "gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogIn, { className: "size-3.5" }), "Portal login"]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "sm",
						className: "gap-1.5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/auth/sign-up",
							children: ["Book a tour ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3.5" })]
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "sm",
					className: "sm:hidden",
					onClick: () => setOpen((v) => !v),
					children: "Menu"
				})
			]
		}), open && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "sm:hidden border-t bg-background px-4 py-4 space-y-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "#branches",
					onClick: () => setOpen(false),
					className: "block text-sm py-1",
					children: "Branches"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "#union-station",
					onClick: () => setOpen(false),
					className: "block text-sm py-1",
					children: "Union Station"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "#membership",
					onClick: () => setOpen(false),
					className: "block text-sm py-1",
					children: "Membership"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "#community",
					onClick: () => setOpen(false),
					className: "block text-sm py-1",
					children: "Community"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2 pt-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						size: "sm",
						className: "flex-1",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/auth/sign-in",
							children: "Portal login"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "sm",
						className: "flex-1",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/auth/sign-up",
							children: "Book a tour"
						})
					})]
				})
			]
		})]
	});
}
function Hero() {
	const [i, setI] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const id = setInterval(() => setI((p) => (p + 1) % slides.length), 5500);
		return () => clearInterval(id);
	}, []);
	const s = slides[i];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "relative overflow-hidden",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative h-[86vh] min-h-140 max-h-205 w-full",
			children: [
				slides.map((sl, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `absolute inset-0 transition-opacity duration-1000 ${idx === i ? "opacity-100" : "opacity-0"}`,
					"aria-hidden": idx !== i,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: sl.img,
							alt: `${sl.name} — ${sl.tag}`,
							width: 1600,
							height: 1e3,
							className: "h-full w-full object-cover",
							loading: idx === 0 ? "eager" : "lazy",
							fetchPriority: idx === 0 ? "high" : "auto"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-linear-to-t from-black/85 via-black/45 to-black/20" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-linear-to-r from-black/60 via-transparent to-black/20" })
					]
				}, sl.name)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative mx-auto max-w-7xl h-full px-4 sm:px-6 flex flex-col justify-end pb-16 md:pb-24 text-white",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
							variant: "outline",
							className: "self-start bg-white/10 border-white/20 text-white gap-1.5 mb-5 backdrop-blur",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-3" }),
								" ",
								s.name,
								" · ",
								s.tag
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-semibold tracking-tight max-w-3xl leading-[1.02]",
							children: "Workspaces that work as hard as you do."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-5 text-sm sm:text-base md:text-lg text-white/85 max-w-xl leading-relaxed",
							children: [s.copy, " Premium coworking, private offices and Johannesburg's most-booked corporate event venue — all under one membership."]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-7 flex flex-wrap items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								size: "lg",
								className: "gap-1.5",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/auth/sign-up",
									children: ["Book a tour ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								size: "lg",
								variant: "outline",
								className: "bg-white/10 border-white/30 text-white hover:bg-white/20 hover:text-white",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/auth/sign-in",
									className: "gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogIn, { className: "size-4" }), "Portal login"]
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 hidden sm:flex flex-wrap items-center gap-x-6 gap-y-2 text-xs text-white/75",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5 text-emerald-400" }), " Day passes from R220"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5 text-emerald-400" }), " 24/7 across all branches"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5 text-emerald-400" }), " Cancel anytime"]
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					"aria-label": "Previous slide",
					onClick: () => setI((i - 1 + slides.length) % slides.length),
					className: "hidden md:grid absolute left-5 top-1/2 -translate-y-1/2 size-11 place-items-center rounded-full bg-white/10 border border-white/20 text-white backdrop-blur hover:bg-white/20",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					"aria-label": "Next slide",
					onClick: () => setI((i + 1) % slides.length),
					className: "hidden md:grid absolute right-5 top-1/2 -translate-y-1/2 size-11 place-items-center rounded-full bg-white/10 border border-white/20 text-white backdrop-blur hover:bg-white/20",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute bottom-5 left-1/2 -translate-x-1/2 flex items-center gap-2",
					children: slides.map((sl, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						"aria-label": sl.name,
						onClick: () => setI(idx),
						className: `h-1.5 rounded-full transition-all ${idx === i ? "w-8 bg-white" : "w-3 bg-white/40 hover:bg-white/70"}`
					}, sl.name))
				})
			]
		})
	});
}
function PortalCTA() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "border-b bg-muted/30",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-4 sm:px-6 py-8 grid md:grid-cols-[1fr_auto] gap-4 items-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[11px] uppercase tracking-[0.18em] text-brand font-medium mb-1",
					children: "Members & staff"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-display text-lg md:text-xl font-semibold",
					children: "Sign in to the WorkspaceOS portal"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground mt-1 max-w-xl",
					children: "Group CEO, Sales, Branch, Community, Finance, Union Station admin and tenant admins each land in a personalised dashboard. Try the demo accounts on the sign-in page."
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					className: "gap-1.5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/auth/sign-in",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogIn, { className: "size-4" }), "Portal login"]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "outline",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/auth/sign-up",
						children: "Request access"
					})
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-4 sm:px-6 pb-8 flex flex-wrap gap-1.5",
			children: [demoAccounts.slice(0, 5).map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
				variant: "outline",
				className: "text-[10px] bg-card",
				children: a.label.split(" — ")[1] ?? a.label
			}, a.email)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
				variant: "outline",
				className: "text-[10px] bg-card",
				children: [
					"+ ",
					demoAccounts.length - 5,
					" more"
				]
			})]
		})]
	});
}
function Branches() {
	const live = branches.filter((b) => b.status === "live");
	const planned = branches.filter((b) => b.status === "planned");
	const imgs = {
		Bryanston: space_bryanston_default,
		Rosebank: space_rosebank_default,
		Kyalami: space_kyalami_default,
		"Union Station": space_union_station_default
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "branches",
		className: "py-16 md:py-24 border-y",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-4 sm:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-end justify-between mb-8 md:mb-10 flex-wrap gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[11px] uppercase tracking-[0.18em] text-brand font-medium mb-2",
						children: "Our branches"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl md:text-4xl font-semibold",
						children: "Designed in Johannesburg. Going national."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground max-w-md",
						children: "Four locations live today. Sandton, Cape Town and Durban coming soon — your membership travels with you."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid sm:grid-cols-2 lg:grid-cols-4 gap-4",
					children: live.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "card-soft overflow-hidden group hover:shadow-elevated transition-shadow",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "aspect-4/3 overflow-hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: imgs[b.name] ?? "/p/o&co/assets/space-bryanston-PTa5Jxpf.jpg",
								alt: b.name,
								width: 800,
								height: 600,
								loading: "lazy",
								className: "h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-display text-lg font-semibold",
									children: b.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs text-muted-foreground flex items-center gap-1 mt-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3" }),
										" ",
										b.city,
										" · ",
										b.region
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 pt-3 border-t text-xs text-muted-foreground flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [Math.round(b.occupancy * 100), "% occupied"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/auth/sign-up",
										className: "text-brand hover:underline",
										children: "Tour →"
									})]
								})
							]
						})]
					}, b.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs uppercase tracking-wider text-muted-foreground font-medium mb-3",
						children: "Coming soon"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: planned.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
							variant: "outline",
							className: "text-xs gap-1 bg-card",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3" }),
								" ",
								b.name
							]
						}, b.id))
					})]
				})
			]
		})
	});
}
function UnionStationFeature() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "union-station",
		className: "py-16 md:py-24",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-4 sm:px-6 grid lg:grid-cols-2 gap-10 lg:gap-12 items-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "order-2 lg:order-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
						variant: "outline",
						className: "mb-4 gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, { className: "size-3" }), " Union Station"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl md:text-4xl font-semibold tracking-tight",
						children: "Johannesburg's most-booked corporate event venue."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 text-muted-foreground leading-relaxed",
						children: "A restored heritage building. Four halls. 450 capacity. From investor briefings and product launches to year-end galas — Union Station delivers world-class corporate events in the heart of the city."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-6 space-y-3 text-sm",
						children: [
							"Capacity from 24 (boardroom) to 450 (banquet/theatre)",
							"Pro AV, streaming, simultaneous translation",
							"Award-winning catering — coffee breaks to gala dinners",
							"Dedicated events team · 4-hour quote turnaround"
						].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-start gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4 text-brand shrink-0 mt-0.5" }),
								" ",
								t
							]
						}, t))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-7 flex flex-wrap gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							className: "gap-1.5",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/auth/sign-in",
								children: ["Request a quote ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							children: "Download brochure"
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "order-1 lg:order-2 relative",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "aspect-4/3 rounded-2xl overflow-hidden shadow-elevated",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: space_union_station_default,
						alt: "Union Station Grand Hall",
						width: 1600,
						height: 1200,
						loading: "lazy",
						className: "h-full w-full object-cover"
					})
				})
			})]
		})
	});
}
function Membership() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "membership",
		className: "py-16 md:py-24 bg-muted/30 border-y",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-4 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-center mb-10 md:mb-12 max-w-2xl mx-auto",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[11px] uppercase tracking-[0.18em] text-brand font-medium mb-2",
						children: "Membership"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl md:text-4xl font-semibold",
						children: "A plan for every stage."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-muted-foreground",
						children: "One membership. Every branch. Cancel anytime."
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid sm:grid-cols-2 lg:grid-cols-4 gap-4",
				children: [
					{
						name: "Day Pass",
						price: "R220",
						period: "/day",
						desc: "Walk-in access, single branch.",
						features: [
							"High-speed Wi-Fi",
							"Café credit R30",
							"Meeting room booking"
						],
						cta: "Start today"
					},
					{
						name: "Flex",
						price: "R1,950",
						period: "/month",
						desc: "Hot desk, any branch, anytime.",
						features: [
							"All branches included",
							"8 meeting room hours/mo",
							"Community events",
							"Mail handling"
						],
						cta: "Most popular",
						featured: true
					},
					{
						name: "Dedicated",
						price: "R4,890",
						period: "/month",
						desc: "Your desk. Your branch. Your team.",
						features: [
							"Reserved desk",
							"20 meeting room hours/mo",
							"Storage",
							"Phone booth access"
						],
						cta: "Reserve"
					},
					{
						name: "Private Office",
						price: "From R12,500",
						period: "/month",
						desc: "Branded private suites for 4–40.",
						features: [
							"Fully furnished",
							"Custom signage",
							"Dedicated AV",
							"Concierge support"
						],
						cta: "Talk to sales"
					}
				].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `card-soft p-6 flex flex-col ${t.featured ? "ring-2 ring-brand shadow-elevated" : ""}`,
					children: [
						t.featured && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							className: "self-start mb-3",
							children: "Most popular"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-display text-lg font-semibold",
							children: t.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-3xl font-semibold",
								children: t.price
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted-foreground",
								children: t.period
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground mt-1",
							children: t.desc
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-5 space-y-2 text-sm flex-1",
							children: t.features.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-start gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4 text-brand shrink-0 mt-0.5" }), f]
							}, f))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: t.featured ? "default" : "outline",
							className: "mt-6",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/auth/sign-up",
								children: t.cta
							})
						})
					]
				}, t.name))
			})]
		})
	});
}
function Community() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "community",
		className: "py-16 md:py-24",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto max-w-7xl px-4 sm:px-6 grid sm:grid-cols-2 md:grid-cols-3 gap-4 md:gap-6",
			children: [
				{
					icon: Users,
					t: "A real community",
					d: "1,200+ members, weekly events, intros that turn into deals."
				},
				{
					icon: Calendar,
					t: "Events every week",
					d: "Founders breakfasts, Wine Down Fridays, workshops, summits."
				},
				{
					icon: Coffee,
					t: "Cafés you'll love",
					d: "Specialty coffee, lunch, kitchen credit included in most plans."
				},
				{
					icon: ShieldCheck,
					t: "POPIA & ISO 27001",
					d: "Enterprise-grade security, privacy, and access control."
				},
				{
					icon: Building2,
					t: "Locations everywhere",
					d: "Johannesburg today. Cape Town & Durban next."
				},
				{
					icon: Sparkles,
					t: "Member rewards",
					d: "Discounts at 80+ partner brands across SA."
				}
			].map((f, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "card-soft p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid size-10 place-items-center rounded-lg bg-brand-soft text-brand mb-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(f.icon, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-display font-semibold",
						children: f.t
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground mt-1.5",
						children: f.d
					})
				]
			}, i))
		})
	});
}
function FAQ() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "py-16 md:py-24 bg-muted/30 border-y",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-3xl px-4 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-center mb-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[11px] uppercase tracking-[0.18em] text-brand font-medium mb-2",
					children: "FAQ"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl md:text-4xl font-semibold",
					children: "Questions, answered."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-3",
				children: [
					{
						q: "Can I use my membership at every branch?",
						a: "Yes. Flex, Dedicated and Private Office members have 24/7 access across all live Office & Co branches."
					},
					{
						q: "How fast can I move in?",
						a: "Hot desks and dedicated plans are typically same-day. Private suites and offices: 2-7 days."
					},
					{
						q: "Can I book Union Station even if I'm not a member?",
						a: "Absolutely. Union Station is open to all companies. Submit a quote request and our events team will respond within 4 hours."
					},
					{
						q: "Is there a contract?",
						a: "No long-term contracts on Flex or Dedicated — month-to-month. Private offices typically run on 6-12 month terms."
					}
				].map((q) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
					className: "card-soft p-5 group",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", {
						className: "font-medium cursor-pointer flex justify-between items-center gap-3",
						children: [q.q, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground group-open:rotate-45 transition-transform",
							children: "+"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground mt-2",
						children: q.a
					})]
				}, q.q))
			})]
		})
	});
}
function CTA() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "py-16 md:py-24",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto max-w-5xl px-4 sm:px-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl bg-primary text-primary-foreground p-8 md:p-12 text-center relative overflow-hidden shadow-elevated",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 surface-grid opacity-[0.06]" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "relative font-display text-3xl md:text-4xl font-semibold",
						children: "Come work how you actually want to work."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "relative text-white/70 mt-3 max-w-xl mx-auto",
						children: "Book a tour at any branch. Walk in. Plug in. Belong."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative mt-7 flex flex-wrap justify-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							size: "lg",
							variant: "secondary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/auth/sign-up",
								children: "Book a tour"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							size: "lg",
							variant: "outline",
							className: "bg-transparent text-white border-white/30 hover:bg-white/10 hover:text-white",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/auth/sign-in",
								children: "Portal login"
							})
						})]
					})
				]
			})
		})
	});
}
function Footer() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "border-t py-12 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-4 sm:px-6 grid sm:grid-cols-2 md:grid-cols-4 gap-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid size-8 place-items-center rounded-md bg-primary",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrandLogo, { className: "size-5 object-contain" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-display font-semibold",
					children: "Office & Co"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-xs text-muted-foreground",
				children: "Workspaces that work as hard as you do."
			})] }), [
				{
					t: "Locations",
					l: [
						"Kyalami",
						"Bryanston",
						"Rosebank",
						"Union Station"
					]
				},
				{
					t: "Company",
					l: [
						"About",
						"Careers",
						"Press",
						"Contact"
					]
				},
				{
					t: "Legal",
					l: [
						"Terms",
						"Privacy (POPIA)",
						"Security",
						"Cookies"
					]
				}
			].map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-xs uppercase tracking-wider text-muted-foreground font-medium mb-3",
				children: c.t
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2 text-foreground/80",
				children: c.l.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "#",
					className: "hover:text-foreground",
					children: i
				}) }, i))
			})] }, c.t))]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-4 sm:px-6 mt-10 pt-6 border-t flex flex-wrap items-center justify-between gap-2 text-[11px] text-muted-foreground",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				"© ",
				(/* @__PURE__ */ new Date()).getFullYear(),
				" Office & Co Group · Anthony Manas, Group CEO"
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: "Made in Johannesburg." })]
		})]
	});
}
//#endregion
export { Welcome as component };
