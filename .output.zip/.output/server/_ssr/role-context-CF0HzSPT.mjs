import { i as __toESM } from "../_runtime.mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as ROLES, t as COMMUNITY_MODULES } from "./mock-B_SZb7O5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/role-context-CF0HzSPT.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var RoleContext = (0, import_react.createContext)(null);
var STORAGE_KEY = "woos.role";
var COMMUNITY_KEY = "woos.ceo.showCommunity";
var OVERRIDES_KEY = "woos.communityOverrides";
var urlToKey = new Map(COMMUNITY_MODULES.map((m) => [m.url, m.key]));
function RoleProvider({ children }) {
	const [roleId, setRoleId] = (0, import_react.useState)("group-ceo");
	const [showCommunity, setShowCommunity] = (0, import_react.useState)(true);
	const [overrides, setOverrides] = (0, import_react.useState)({});
	(0, import_react.useEffect)(() => {
		if (typeof window === "undefined") return;
		const stored = window.localStorage.getItem(STORAGE_KEY);
		if (stored && ROLES.find((r) => r.id === stored)) setRoleId(stored);
		const sc = window.localStorage.getItem(COMMUNITY_KEY);
		if (sc !== null) setShowCommunity(sc === "1");
		const ov = window.localStorage.getItem(OVERRIDES_KEY);
		if (ov) try {
			setOverrides(JSON.parse(ov));
		} catch {}
	}, []);
	(0, import_react.useEffect)(() => {
		if (typeof window !== "undefined") window.localStorage.setItem(STORAGE_KEY, roleId);
	}, [roleId]);
	(0, import_react.useEffect)(() => {
		if (typeof window !== "undefined") window.localStorage.setItem(COMMUNITY_KEY, showCommunity ? "1" : "0");
	}, [showCommunity]);
	(0, import_react.useEffect)(() => {
		if (typeof window !== "undefined") window.localStorage.setItem(OVERRIDES_KEY, JSON.stringify(overrides));
	}, [overrides]);
	const role = ROLES.find((r) => r.id === roleId) ?? ROLES[0];
	const getRoleAccess = (0, import_react.useCallback)((rid, key) => {
		const ov = overrides[rid]?.[key];
		if (typeof ov === "boolean") return ov;
		return ROLES.find((r) => r.id === rid)?.communityModules[key] ?? false;
	}, [overrides]);
	const setRoleAccess = (0, import_react.useCallback)((rid, key, value) => {
		setOverrides((prev) => ({
			...prev,
			[rid]: {
				...prev[rid],
				[key]: value
			}
		}));
	}, []);
	const moduleAccess = COMMUNITY_MODULES.reduce((acc, m) => {
		acc[m.key] = getRoleAccess(role.id, m.key);
		return acc;
	}, {});
	const canAccessUrl = (0, import_react.useCallback)((url) => {
		if (!role.nav.includes(url)) return false;
		const key = urlToKey.get(url);
		if (!key) return true;
		if (role.id === "group-ceo" && !showCommunity) return false;
		return getRoleAccess(role.id, key);
	}, [
		role,
		showCommunity,
		getRoleAccess
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoleContext.Provider, {
		value: {
			role,
			setRoleId,
			roles: ROLES,
			showCommunity,
			setShowCommunity,
			moduleAccess,
			getRoleAccess,
			setRoleAccess,
			canAccessUrl
		},
		children
	});
}
function useRole() {
	const ctx = (0, import_react.useContext)(RoleContext);
	if (!ctx) throw new Error("useRole must be used within RoleProvider");
	return ctx;
}
//#endregion
export { useRole as n, RoleProvider as t };
