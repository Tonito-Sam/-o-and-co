import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { t as Badge } from "./badge-D1Dupn2y.mjs";
import { t as PageHeader } from "./PageHeader-BGUb7ose.mjs";
import { g as ShieldAlert } from "../_libs/lucide-react.mjs";
import { n as ROLES, t as COMMUNITY_MODULES } from "./mock-B_SZb7O5.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as useRole } from "./role-context-CF0HzSPT.mjs";
import { t as Switch } from "./switch-Cn1w-cIH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings.roles-DDLQWl28.js
var import_jsx_runtime = require_jsx_runtime();
function RoleSettings() {
	const { role, getRoleAccess, setRoleAccess, showCommunity } = useRole();
	if (!(role.id === "group-ceo")) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl card-soft p-8 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-8 text-warning mx-auto mb-3" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: "Restricted"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground mt-2",
				children: "Role module access is managed by the Group CEO. Switch your view in the top bar to manage."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				className: "mt-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					children: "Back to overview"
				})
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-[1300px]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				eyebrow: "Platform · Administration",
				title: "Role-based community access",
				description: "Decide which community modules each role can see. Toggles are stored locally and apply instantly to the sidebar and dashboards."
			}),
			!showCommunity && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 rounded-md border border-warning/30 bg-warning/10 p-3 text-xs flex items-start gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-4 text-warning shrink-0 mt-px" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-medium text-warning",
					children: "Master community switch is OFF for the Group CEO."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-foreground/80",
					children: "Community modules are currently hidden for your view regardless of per-role settings. Re-enable in the top bar."
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "card-soft overflow-hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "bg-muted/30 border-b",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "text-left px-4 py-3 text-[11px] uppercase tracking-wider font-medium text-muted-foreground",
							children: "Role"
						}), COMMUNITY_MODULES.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "text-center px-3 py-3 text-[11px] uppercase tracking-wider font-medium text-muted-foreground",
							children: m.label
						}, m.key))] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: ROLES.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b last:border-0 hover:bg-muted/20",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid size-8 place-items-center rounded-full bg-brand-soft text-brand text-xs font-medium",
										children: r.initials
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "leading-tight",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-sm font-medium",
											children: r.user
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[11px] text-muted-foreground",
											children: r.title
										})]
									}),
									r.id === "group-ceo" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: "outline",
										className: "text-[10px] ml-2",
										children: "Admin"
									})
								]
							})
						}), COMMUNITY_MODULES.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "text-center px-3 py-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
								checked: getRoleAccess(r.id, m.key),
								onCheckedChange: (v) => setRoleAccess(r.id, m.key, v),
								"aria-label": `${r.user} · ${m.label}`
							})
						}, m.key))]
					}, r.id)) })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 text-[11px] text-muted-foreground",
				children: [
					"Note: These settings layer on top of the role's base navigation. The Group CEO's ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Community" }),
					" master switch in the top bar still overrides everything for the CEO view."
				]
			})
		]
	});
}
//#endregion
export { RoleSettings as component };
