import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { t as Badge } from "./badge-D1Dupn2y.mjs";
import { t as PageHeader } from "./PageHeader-BGUb7ose.mjs";
import { X as Coffee, ct as CalendarRange, dt as Bell, f as Sparkles, m as ShoppingBag, n as Wallet, r as Users, z as Headphones } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/mobile-app-l2QVs6EC.js
var import_jsx_runtime = require_jsx_runtime();
function MobileApp() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-[1100px]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: "Tenant Mobile App",
			title: "The pocket workspace",
			description: "Native-feeling iOS and Android. Bookings, café, community, invoices — one tap from anywhere."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid lg:grid-cols-2 gap-10 items-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-5",
				children: [
					{
						icon: CalendarRange,
						title: "Bookings",
						text: "Reserve any room at any branch in seconds."
					},
					{
						icon: Wallet,
						title: "Invoices",
						text: "Pay outstanding amounts or charge to account."
					},
					{
						icon: Coffee,
						title: "Café",
						text: "Order ahead. Skip the queue."
					},
					{
						icon: Users,
						title: "Community",
						text: "Welcomes, announcements, hiring, launches."
					},
					{
						icon: Headphones,
						title: "Podcasts & content",
						text: "Stream the Office & Co library on the go."
					},
					{
						icon: ShoppingBag,
						title: "Marketplace",
						text: "Office supplies and tenant-to-tenant services."
					},
					{
						icon: Bell,
						title: "Smart notifications",
						text: "Only what matters — email, SMS, WhatsApp or push."
					}
				].map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid size-10 shrink-0 place-items-center rounded-lg bg-brand-soft text-brand",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(f.icon, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-display font-semibold",
						children: f.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-sm text-muted-foreground",
						children: f.text
					})] })]
				}, f.title))
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "relative w-[300px] h-[620px] rounded-[44px] bg-foreground p-3 shadow-elevated",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "w-full h-full rounded-[34px] bg-background overflow-hidden flex flex-col",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-7 bg-foreground rounded-b-2xl mx-auto w-1/3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "px-5 py-4 flex-1 overflow-hidden",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[10px] text-muted-foreground",
									children: "Tuesday, 23 June"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-display text-xl font-semibold mt-0.5",
									children: "Good morning, Aisha"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "outline",
									className: "text-[10px] mt-1",
									children: "Mosaic Studio · Rosebank"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "card-soft p-3 mt-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[10px] uppercase tracking-wider text-brand font-medium",
											children: "Next up"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-sm font-medium mt-0.5",
											children: "Karoo Meeting Room"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[11px] text-muted-foreground",
											children: "11:00 — 12:00 · Bryanston"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-3 gap-2 mt-3",
									children: [
										{
											i: CalendarRange,
											l: "Book"
										},
										{
											i: Coffee,
											l: "Café"
										},
										{
											i: ShoppingBag,
											l: "Store"
										}
									].map((q) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-lg bg-muted/50 p-2.5 grid place-items-center text-[10px] gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(q.i, { className: "size-4 text-brand" }), q.l]
									}, q.l))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "card-soft p-3 mt-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-3 text-brand" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[10px] uppercase tracking-wider text-muted-foreground font-medium",
											children: "Community"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[11px] mt-1",
										children: "Please welcome John Smith from ABC Consulting 🎉"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "card-soft p-3 mt-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[10px] uppercase tracking-wider text-muted-foreground font-medium",
										children: "Outstanding"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between mt-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[11px]",
											children: "INV-2026-0873"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[11px] font-medium",
											children: "R 29,900"
										})]
									})]
								})
							]
						})]
					})
				})
			})]
		})]
	});
}
//#endregion
export { MobileApp as component };
