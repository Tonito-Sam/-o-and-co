import { i as __toESM } from "../_runtime.mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { _ as useNavigate, g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as AuthLayout } from "./AuthLayout-DSd_oWxZ.mjs";
import { n as InputOTPGroup, r as InputOTPSlot, t as InputOTP } from "./input-otp-DjrJa5vK.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth.verify-email-BkldiEKJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Verify() {
	const nav = useNavigate();
	const [code, setCode] = (0, import_react.useState)("");
	const verify = () => {
		if (code.length !== 6) {
			toast.error("Enter the full 6-digit code.");
			return;
		}
		toast.success("Email verified. Welcome aboard.");
		nav({ to: "/" });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthLayout, {
		eyebrow: "Verify your email",
		title: "Check your inbox for a code.",
		subtitle: "We've sent a 6-digit code to your work email. Enter it below to activate your account.",
		footer: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/auth/sign-in",
			className: "text-brand font-medium hover:underline",
			children: "Back to sign in"
		}),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex justify-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputOTP, {
						maxLength: 6,
						value: code,
						onChange: setCode,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputOTPGroup, { children: [
							0,
							1,
							2,
							3,
							4,
							5
						].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputOTPSlot, { index: i }, i)) })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: verify,
					className: "w-full",
					children: "Verify email"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => toast.success("New code sent."),
					className: "text-xs text-brand hover:underline mx-auto block",
					children: "Resend code"
				})
			]
		})
	});
}
//#endregion
export { Verify as component };
