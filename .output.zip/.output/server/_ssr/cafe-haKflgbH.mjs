import { i as __toESM } from "../_runtime.mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { t as Badge } from "./badge-D1Dupn2y.mjs";
import { n as StatCard, t as PageHeader } from "./PageHeader-BGUb7ose.mjs";
import { C as Plus, E as Minus, L as History, X as Coffee, b as RotateCcw, c as Trash2, it as ChefHat, m as ShoppingBag, u as Store } from "../_libs/lucide-react.mjs";
import { D as tenantOrderHistory, _ as formatZAR, a as cafeProducts, i as cafeOrders, n as ROLES, r as branches } from "./mock-B_SZb7O5.mjs";
import { t as Label } from "./label-DBD1bRRP.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as useRole } from "./role-context-CF0HzSPT.mjs";
import { i as SelectItem, n as SelectContent, o as SelectTrigger, s as SelectValue, t as Select } from "./select-DG_6GgLn.mjs";
import { t as Switch } from "./switch-Cn1w-cIH.mjs";
import { t as Textarea } from "./textarea-kko37XEX.mjs";
import { i as TabsTrigger, n as TabsContent, r as TabsList, t as Tabs } from "./tabs-CCJRliUM.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, s as DialogTrigger, t as Dialog } from "./dialog-DIo89e4g.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-C0WYWEQX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cafe-haKflgbH.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var liveBranches = branches.filter((b) => b.status === "live").map((b) => b.name);
var columns = [
	"Queued",
	"Preparing",
	"Ready",
	"Collected"
];
function tenantBranchFor(roleId) {
	return (ROLES.find((x) => x.id === roleId)?.scope.match(/(Bryanston|Kyalami|Rosebank|Union Station)/))?.[1] ?? "Bryanston";
}
function Cafe() {
	const { role } = useRole();
	const isAdmin = [
		"group-ceo",
		"branch-manager",
		"community-manager",
		"lydia-admin"
	].includes(role.id);
	const [tab, setTab] = (0, import_react.useState)(isAdmin ? "admin" : "shop");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-[1400px]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: "Café",
			title: "Office & Co Café",
			description: isAdmin ? "Manage products and the kitchen board per branch — what tenants see in their app updates instantly." : "Order from your branch café and have it ready when you walk in. Charge to your account or pay now."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
			value: tab,
			onValueChange: setTab,
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
					className: "flex-wrap h-auto",
					children: [
						isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
							value: "admin",
							className: "gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChefHat, { className: "size-3.5" }), "Admin · Products"]
						}),
						isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
							value: "kitchen",
							className: "gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Coffee, { className: "size-3.5" }), "Kitchen board"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
							value: "shop",
							className: "gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Store, { className: "size-3.5" }), "Shop"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
							value: "orders",
							className: "gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { className: "size-3.5" }), "My orders"]
						})
					]
				}),
				isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "admin",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminPanel, {})
				}),
				isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "kitchen",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KitchenBoard, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "shop",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shop, {
						defaultBranch: tenantBranchFor(role.id),
						canPickBranch: isAdmin
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "orders",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MyOrders, { branch: tenantBranchFor(role.id) })
				})
			]
		})]
	});
}
function AdminPanel() {
	const [branch, setBranch] = (0, import_react.useState)(liveBranches[0]);
	const [products, setProducts] = (0, import_react.useState)(cafeProducts);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [editing, setEditing] = (0, import_react.useState)(null);
	const branchProducts = products.filter((p) => p.branch === branch);
	const stats = {
		total: branchProducts.length,
		live: branchProducts.filter((p) => p.available).length,
		popular: branchProducts.filter((p) => p.popular).length
	};
	const upsert = (p) => {
		setProducts((prev) => {
			return prev.find((x) => x.id === p.id) ? prev.map((x) => x.id === p.id ? p : x) : [p, ...prev];
		});
		toast.success(editing ? `Updated ${p.name}` : `${p.name} added to ${p.branch}`);
		setEditing(null);
		setOpen(false);
	};
	const remove = (id) => {
		setProducts((prev) => prev.filter((p) => p.id !== id));
		toast.success("Product removed");
	};
	const toggleAvail = (id) => {
		setProducts((prev) => prev.map((p) => p.id === id ? {
			...p,
			available: !p.available
		} : p));
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-end justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-xs mb-1.5 block",
					children: "Managing branch"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: branch,
					onValueChange: setBranch,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
						className: "w-[220px]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: liveBranches.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: b,
						children: b
					}, b)) })]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2 ml-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
							variant: "outline",
							children: [stats.total, " products"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
							variant: "outline",
							className: "text-success border-success/30",
							children: [stats.live, " live"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
							variant: "outline",
							className: "text-brand border-brand/30",
							children: [stats.popular, " popular"]
						})
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
				open,
				onOpenChange: (v) => {
					setOpen(v);
					if (!v) setEditing(null);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						className: "gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "New product"]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductDialog, {
					branch,
					initial: editing,
					onSave: upsert,
					onClose: () => {
						setOpen(false);
						setEditing(null);
					}
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "card-soft overflow-hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Product" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Category" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
					className: "text-right",
					children: "Price"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Status" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
					className: "text-right",
					children: "Actions"
				})
			] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableBody, { children: [branchProducts.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "font-medium text-sm flex items-center gap-2",
					children: [p.name, p.popular && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: "secondary",
						className: "text-[10px]",
						children: "Popular"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[11px] text-muted-foreground line-clamp-1",
					children: p.description
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					variant: "outline",
					className: "text-[10px]",
					children: p.category
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
					className: "text-right tabular-nums",
					children: formatZAR(p.price)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
						checked: p.available,
						onCheckedChange: () => toggleAvail(p.id)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted-foreground",
						children: p.available ? "Available" : "Hidden"
					})]
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
					className: "text-right",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "inline-flex gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "ghost",
							className: "h-7",
							onClick: () => {
								setEditing(p);
								setOpen(true);
							},
							children: "Edit"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon",
							variant: "ghost",
							className: "size-7 text-destructive hover:text-destructive",
							onClick: () => remove(p.id),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" })
						})]
					})
				})
			] }, p.id)), branchProducts.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableRow, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
				colSpan: 5,
				className: "text-center text-sm text-muted-foreground py-8",
				children: [
					"No products yet for ",
					branch,
					". Add the first one."
				]
			}) })] })] })
		})]
	});
}
function ProductDialog({ branch, initial, onSave, onClose }) {
	const [form, setForm] = (0, import_react.useState)(initial ?? {
		id: `CP-${Math.random().toString(36).slice(2, 7).toUpperCase()}`,
		branch,
		name: "",
		category: "Coffee",
		price: 35,
		description: "",
		available: true,
		popular: false
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: initial ? "Edit product" : "New product" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
			"Visible only to tenants at ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: branch }),
			"."
		] })] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5 col-span-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Name" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: form.name,
								onChange: (e) => setForm({
									...form,
									name: e.target.value
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Category" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: form.category,
								onValueChange: (v) => setForm({
									...form,
									category: v
								}),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: [
									"Coffee",
									"Tea",
									"Cold Drinks",
									"Bakery",
									"Breakfast",
									"Lunch",
									"Snacks"
								].map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: c,
									children: c
								}, c)) })]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Price (ZAR)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								value: form.price,
								onChange: (e) => setForm({
									...form,
									price: Number(e.target.value)
								})
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Description" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						rows: 2,
						value: form.description,
						onChange: (e) => setForm({
							...form,
							description: e.target.value
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: form.available,
							onCheckedChange: (v) => setForm({
								...form,
								available: v
							})
						}), " Available"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: !!form.popular,
							onCheckedChange: (v) => setForm({
								...form,
								popular: v
							})
						}), " Mark popular"]
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "outline",
			onClick: onClose,
			children: "Cancel"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			onClick: () => {
				if (!form.name) {
					toast.error("Name is required");
					return;
				}
				onSave({
					...form,
					branch
				});
			},
			children: initial ? "Save" : "Add product"
		})] })
	] });
}
function KitchenBoard() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-2 md:grid-cols-4 gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Orders today",
					value: "187",
					delta: "▲ 14",
					accent: "brand"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Café revenue (mo)",
					value: formatZAR(284e3),
					accent: "success"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Charge to account",
					value: "62%",
					hint: "of all orders"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Avg prep time",
					value: "4.2 min"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid md:grid-cols-4 gap-3",
			children: columns.map((col) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl bg-muted/40 p-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between mb-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs font-semibold uppercase tracking-wider text-foreground/70",
						children: col
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: "outline",
						className: "text-[10px]",
						children: cafeOrders.filter((o) => o.status === col).length
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-2",
					children: cafeOrders.filter((o) => o.status === col).map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "card-soft p-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid size-8 place-items-center rounded-md bg-warning/15 text-warning shrink-0",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Coffee, { className: "size-4" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1 min-w-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-sm font-medium leading-tight",
										children: o.item
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-[11px] text-muted-foreground mt-0.5",
										children: [
											o.member,
											" · ",
											o.tenant
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[10px] mt-1 text-brand",
										children: o.method
									})
								]
							})]
						})
					}, o.id))
				})]
			}, col))
		})]
	});
}
function Shop({ defaultBranch, canPickBranch }) {
	const [branch, setBranch] = (0, import_react.useState)(defaultBranch);
	const [cat, setCat] = (0, import_react.useState)("All");
	const [cart, setCart] = (0, import_react.useState)({});
	const items = (0, import_react.useMemo)(() => cafeProducts.filter((p) => p.branch === branch && p.available && (cat === "All" || p.category === cat)), [branch, cat]);
	const cats = (0, import_react.useMemo)(() => {
		const set = /* @__PURE__ */ new Set();
		cafeProducts.filter((p) => p.branch === branch && p.available).forEach((p) => set.add(p.category));
		return ["All", ...set];
	}, [branch]);
	const inc = (id) => setCart((c) => ({
		...c,
		[id]: (c[id] ?? 0) + 1
	}));
	const dec = (id) => setCart((c) => {
		const n = (c[id] ?? 0) - 1;
		const next = { ...c };
		if (n <= 0) delete next[id];
		else next[id] = n;
		return next;
	});
	const cartItems = Object.entries(cart).map(([id, qty]) => {
		return {
			...cafeProducts.find((x) => x.id === id),
			qty
		};
	});
	const subtotal = cartItems.reduce((s, i) => s + i.price * i.qty, 0);
	const checkout = (method) => {
		if (cartItems.length === 0) return;
		toast.success(`Order placed · ${branch} · ${method} · ${formatZAR(subtotal)}`);
		setCart({});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid lg:grid-cols-[1fr_340px] gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [canPickBranch ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: branch,
						onValueChange: setBranch,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							className: "w-[200px]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: liveBranches.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: b,
							children: b
						}, b)) })]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
						variant: "outline",
						className: "h-8 px-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Store, { className: "size-3 mr-1.5" }),
							branch,
							" Café"
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-1.5 ml-1",
						children: cats.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setCat(c),
							className: `px-2.5 py-1 rounded-full border text-xs ${cat === c ? "bg-brand-soft text-brand border-brand/30" : "hover:bg-muted/50"}`,
							children: c
						}, c))
					})]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid sm:grid-cols-2 lg:grid-cols-3 gap-3",
				children: [items.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card-soft p-4 flex flex-col",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-semibold",
								children: p.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: "outline",
								className: "text-[10px] mt-1",
								children: p.category
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-display text-base font-semibold tabular-nums",
								children: formatZAR(p.price)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground mt-2 flex-1",
							children: p.description
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex items-center justify-between",
							children: [p.popular && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: "secondary",
								className: "text-[10px]",
								children: "⭐ Popular"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "ml-auto flex items-center gap-1.5",
								children: cart[p.id] ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "icon",
										variant: "outline",
										className: "size-7",
										onClick: () => dec(p.id),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-3" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm font-medium w-5 text-center tabular-nums",
										children: cart[p.id]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "icon",
										variant: "outline",
										className: "size-7",
										onClick: () => inc(p.id),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3" })
									})
								] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									variant: "outline",
									className: "h-7 gap-1",
									onClick: () => inc(p.id),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3" }), "Add"]
								})
							})]
						})
					]
				}, p.id)), items.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "col-span-full text-center text-sm text-muted-foreground py-12",
					children: "No items in this category yet."
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "card-soft p-5 h-fit sticky top-20",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between mb-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
						className: "font-display font-semibold flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, { className: "size-4 text-brand" }), "Your order"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
						variant: "outline",
						className: "text-[10px]",
						children: [
							cartItems.length,
							" item",
							cartItems.length !== 1 ? "s" : ""
						]
					})]
				}),
				cartItems.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Add items from the menu to start your order."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-2 max-h-[40vh] overflow-y-auto",
						children: cartItems.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-2 text-sm border-b pb-2 last:border-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-medium",
								children: i.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-[11px] text-muted-foreground",
								children: [
									formatZAR(i.price),
									" × ",
									i.qty
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-medium tabular-nums",
								children: formatZAR(i.price * i.qty)
							})]
						}, i.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border-t pt-3 mt-3 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-muted-foreground",
							children: "Subtotal"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-lg font-semibold tabular-nums",
							children: formatZAR(subtotal)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "w-full mt-3",
						onClick: () => checkout("Charge to account"),
						children: "Charge to account"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						className: "w-full mt-2",
						onClick: () => checkout("Pay now"),
						children: "Pay now"
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 text-[11px] text-muted-foreground",
					children: [
						"Ready for pickup at the ",
						branch,
						" Café counter — average prep time 4 min."
					]
				})
			]
		})]
	});
}
var STATUS_TONE = {
	Queued: "bg-muted text-foreground/70",
	Preparing: "bg-warning/15 text-warning border-warning/30",
	Ready: "bg-brand/15 text-brand border-brand/30",
	Collected: "bg-success/15 text-success border-success/30",
	Shipped: "bg-brand/15 text-brand border-brand/30",
	Delivered: "bg-success/15 text-success border-success/30"
};
function MyOrders({ branch }) {
	const rows = tenantOrderHistory.filter((o) => o.branch === branch && o.kind === "cafe");
	const reorder = (id) => toast.success(`Reordered ${id} — added to your cart`);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-2 md:grid-cols-4 gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Orders (30 days)",
					value: String(rows.length),
					accent: "brand"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Spent this month",
					value: formatZAR(rows.reduce((s, r) => s + r.total, 0)),
					accent: "success"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Charge to account",
					value: `${rows.filter((r) => r.method === "Charge to account").length}`,
					hint: "of total orders"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Home branch",
					value: branch
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "card-soft overflow-hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Order" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Items" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Method" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
					className: "text-right",
					children: "Total"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Status" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
					className: "text-right",
					children: "Actions"
				})
			] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableBody, { children: [rows.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-sm font-medium",
					children: o.id
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[11px] text-muted-foreground",
					children: o.placedAt
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-sm",
					children: o.items.map((i) => `${i.qty}× ${i.name}`).join(" · ")
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
					className: "text-xs",
					children: o.method
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
					className: "text-right tabular-nums",
					children: formatZAR(o.total)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					variant: "outline",
					className: STATUS_TONE[o.status],
					children: o.status
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
					className: "text-right",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "outline",
						className: "h-7 gap-1",
						onClick: () => reorder(o.id),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-3" }), "Reorder"]
					})
				})
			] }, o.id)), rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableRow, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
				colSpan: 6,
				className: "text-center text-sm text-muted-foreground py-8",
				children: [
					"No café orders yet at ",
					branch,
					"."
				]
			}) })] })] })
		})]
	});
}
//#endregion
export { Cafe as component };
