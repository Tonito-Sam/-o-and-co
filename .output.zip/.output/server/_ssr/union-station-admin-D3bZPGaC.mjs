import { i as __toESM } from "../_runtime.mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { b as Legend, c as Area, d as Bar, i as BarChart, o as YAxis, s as XAxis, t as AreaChart, u as CartesianGrid, v as ResponsiveContainer, y as Tooltip } from "../_libs/recharts+[...].mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { t as Badge } from "./badge-D1Dupn2y.mjs";
import { n as StatCard, t as PageHeader } from "./PageHeader-BGUb7ose.mjs";
import { C as Plus, I as Landmark, J as Copy, K as Download, S as Printer, Z as Clock, f as Sparkles, j as Mail, l as Target, o as TriangleAlert, pt as ArrowUpRight, r as Users, s as TrendingUp, x as QrCode } from "../_libs/lucide-react.mjs";
import { A as unionStationRequests, _ as formatZAR, d as conversionByEvent, g as formatInt, m as eventLeadsSample, p as eventAccessCodes, u as conversionByBranch } from "./mock-B_SZb7O5.mjs";
import { t as Label } from "./label-DBD1bRRP.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Progress } from "./progress-DOIEKRJF.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-C0WYWEQX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/union-station-admin-D3bZPGaC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var monthly = [
	{
		m: "Mar",
		rev: 1.1,
		events: 4
	},
	{
		m: "Apr",
		rev: 1.3,
		events: 6
	},
	{
		m: "May",
		rev: 1.45,
		events: 7
	},
	{
		m: "Jun",
		rev: 1.54,
		events: 8
	},
	{
		m: "Jul",
		rev: 1.82,
		events: 11
	},
	{
		m: "Aug",
		rev: 2.04,
		events: 12
	}
];
var gaps = [
	{
		t: "Mondays underbooked",
		d: "Only 18% of Mondays booked across the next 90 days — opportunity for a recurring corporate slot.",
		sev: "high"
	},
	{
		t: "Catering attach-rate",
		d: "32% of confirmed bookings opt for catering. Industry benchmark is 58%.",
		sev: "med"
	},
	{
		t: "AV upsell on Cabaret layouts",
		d: "Only 1 in 4 Cabaret bookings include Pro AV — bundle with quote template.",
		sev: "med"
	},
	{
		t: "Slow turnaround on quotes",
		d: "Avg quote SLA is 9h vs 4h target. 3 quotes overdue.",
		sev: "high"
	}
];
function UnionStationAdmin() {
	const [codes, setCodes] = (0, import_react.useState)(eventAccessCodes);
	const stats = (0, import_react.useMemo)(() => {
		const confirmed = unionStationRequests.filter((r) => r.status === "Confirmed" || r.status === "Invoiced");
		const pipeline = unionStationRequests.filter((r) => [
			"Submitted",
			"In Review",
			"Quoted"
		].includes(r.status));
		const revenueConfirmed = confirmed.reduce((s, r) => s + r.estimate, 0);
		const pipelineValue = pipeline.reduce((s, r) => s + r.estimate, 0);
		const guests = confirmed.reduce((s, r) => s + r.attendees, 0);
		const leadsCaptured = codes.reduce((s, e) => s + e.leadsCaptured, 0);
		const conversions = codes.reduce((s, e) => s + e.conversionsToSales, 0);
		const convRate = leadsCaptured > 0 ? Math.round(conversions / leadsCaptured * 100) : 0;
		return {
			confirmed: confirmed.length,
			pipeline: pipeline.length,
			revenueConfirmed,
			pipelineValue,
			guests,
			leadsCaptured,
			conversions,
			convRate
		};
	}, [codes]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-[1400px]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				eyebrow: "Union Station · Administrator",
				title: "Lydia's command centre",
				description: "A single view of everything keeping Union Station the most-booked corporate venue in Johannesburg — bookings, lead capture, growth and the gaps to close.",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "outline",
					size: "sm",
					className: "gap-1.5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/union-station",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, { className: "size-3.5" }), "Booking workflow"]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					className: "gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4" }), "Weekly briefing"]
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 md:grid-cols-4 gap-4 mb-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Confirmed revenue",
						value: formatZAR(stats.revenueConfirmed),
						delta: "▲ 24% QoQ",
						accent: "success",
						hint: "Q3 to date"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Pipeline value",
						value: formatZAR(stats.pipelineValue),
						delta: `${stats.pipeline} open requests`,
						accent: "brand"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Leads captured",
						value: formatInt(stats.leadsCaptured),
						delta: `+${codes[0].leadsCaptured} from Investec Gala`,
						accent: "brand",
						hint: "via QR check-in"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Lead → Sale",
						value: `${stats.convRate}%`,
						delta: `${stats.conversions} converted`,
						accent: "success"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid lg:grid-cols-3 gap-4 mb-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card-soft p-5 lg:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between mb-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display font-semibold",
							children: "Growth — revenue & events"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "6-month trajectory · Union Station only"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
							variant: "secondary",
							className: "gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "size-3" }), "On track"]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-64",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
							data: monthly,
							margin: {
								left: -10,
								right: 8,
								top: 8
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
									id: "usrev",
									x1: "0",
									y1: "0",
									x2: "0",
									y2: "1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
										offset: "0%",
										stopColor: "oklch(0.5 0.08 195)",
										stopOpacity: .35
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
										offset: "100%",
										stopColor: "oklch(0.5 0.08 195)",
										stopOpacity: 0
									})]
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
									strokeDasharray: "3 3",
									stroke: "oklch(0.92 0.008 95)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
									dataKey: "m",
									tick: {
										fontSize: 11,
										fill: "oklch(0.5 0.02 260)"
									},
									axisLine: false,
									tickLine: false
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
									tick: {
										fontSize: 11,
										fill: "oklch(0.5 0.02 260)"
									},
									axisLine: false,
									tickLine: false
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
									borderRadius: 10,
									border: "1px solid oklch(0.92 0.008 95)",
									fontSize: 12
								} }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
									type: "monotone",
									dataKey: "rev",
									stroke: "oklch(0.5 0.08 195)",
									strokeWidth: 2.5,
									fill: "url(#usrev)",
									name: "Revenue (R m)"
								})
							]
						}) })
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card-soft p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display font-semibold mb-1",
							children: "Operational health"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground mb-4",
							children: "Targets vs actuals"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar2, {
							label: "Capacity utilisation",
							value: 72,
							target: 80
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar2, {
							label: "Quote SLA (≤ 4h)",
							value: 56,
							target: 90
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar2, {
							label: "Repeat bookings",
							value: 38,
							target: 45
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid lg:grid-cols-3 gap-4 mb-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card-soft p-5 lg:col-span-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between mb-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
								className: "font-display font-semibold flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrCode, { className: "size-4 text-brand" }), " Lead capture by event"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: "QR check-ins at Union Station · last 90 days"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								variant: "ghost",
								size: "sm",
								className: "gap-1",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/union-station",
									children: ["Manage codes ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "size-3.5" })]
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-52 mb-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
								data: codes.map((e) => ({
									name: e.title.split(" ").slice(0, 2).join(" "),
									captured: e.leadsCaptured,
									expected: e.attendeesExpected
								})),
								margin: {
									left: -10,
									right: 8,
									top: 8
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
										strokeDasharray: "3 3",
										stroke: "oklch(0.92 0.008 95)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
										dataKey: "name",
										tick: {
											fontSize: 10,
											fill: "oklch(0.5 0.02 260)"
										},
										axisLine: false,
										tickLine: false
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
										tick: {
											fontSize: 11,
											fill: "oklch(0.5 0.02 260)"
										},
										axisLine: false,
										tickLine: false
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
										borderRadius: 10,
										border: "1px solid oklch(0.92 0.008 95)",
										fontSize: 12
									} }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
										dataKey: "expected",
										fill: "oklch(0.92 0.008 95)",
										radius: [
											6,
											6,
											0,
											0
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
										dataKey: "captured",
										fill: "oklch(0.5 0.08 195)",
										radius: [
											6,
											6,
											0,
											0
										]
									})
								]
							}) })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Event" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
								className: "text-right",
								children: "Expected"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
								className: "text-right",
								children: "Captured"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
								className: "text-right",
								children: "Capture %"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
								className: "text-right",
								children: "→ Sales"
							})
						] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: codes.map((e) => {
							const cap = e.attendeesExpected > 0 ? Math.round(e.leadsCaptured / e.attendeesExpected * 100) : 0;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-sm font-medium",
									children: e.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[11px] text-muted-foreground",
									children: [
										e.date,
										" · ",
										e.client
									]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-right tabular-nums",
									children: formatInt(e.attendeesExpected)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-right tabular-nums",
									children: formatInt(e.leadsCaptured)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-right",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
										variant: "outline",
										className: cap >= 80 ? "text-success border-success/30" : cap >= 50 ? "text-brand border-brand/30" : "text-muted-foreground",
										children: [cap, "%"]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-right tabular-nums",
									children: e.conversionsToSales
								})
							] }, e.code);
						}) })] })
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card-soft p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "font-display font-semibold flex items-center gap-2 mb-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-4 text-warning" }), " Gaps to close"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground mb-3",
							children: "Where we're losing revenue or efficiency"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-2.5",
							children: gaps.map((g, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-md border p-3 bg-muted/20",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-sm font-medium",
										children: g.t
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: "outline",
										className: g.sev === "high" ? "text-destructive border-destructive/30" : "text-warning border-warning/30",
										children: g.sev === "high" ? "High" : "Medium"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground mt-1",
									children: g.d
								})]
							}, i))
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrGenerator, {
				codes,
				onAdd: (c) => setCodes((prev) => [c, ...prev])
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConversionAnalytics, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid lg:grid-cols-3 gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card-soft p-5 lg:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center justify-between mb-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "font-display font-semibold flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-4 text-brand" }), " Recent leads captured"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "Auto-routed to Samantha for qualification"
						})] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Name" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Email" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Phone" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Event" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
							className: "text-right",
							children: "Status"
						})
					] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: eventLeadsSample.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "font-medium",
							children: l.fullName
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "text-sm",
							children: l.email
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "text-sm text-muted-foreground",
							children: l.phone ?? "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "text-[11px]",
							children: l.eventCode
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "text-right",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: "outline",
								className: l.status === "Converted" ? "text-success border-success/30" : l.status === "Qualified" ? "text-brand border-brand/30" : "",
								children: l.status
							})
						})
					] }, l.id)) })] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card-soft p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "font-display font-semibold flex items-center gap-2 mb-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Target, { className: "size-4 text-brand" }), " Critical to oversee"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground mb-3",
							children: "Lydia's daily watchlist"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Watch, {
									icon: Clock,
									title: "3 quotes past SLA",
									hint: "Allan Gray, Discovery, TechCabal",
									tone: "warn"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Watch, {
									icon: Users,
									title: "287 leads from Investec Gala",
									hint: "14 converted · 60 awaiting outreach",
									tone: "brand"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Watch, {
									icon: Landmark,
									title: "Heritage Hall maintenance",
									hint: "Scheduled Aug 8 · blocks 1 day",
									tone: "muted"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Watch, {
									icon: TrendingUp,
									title: "Q3 pacing 124% to target",
									hint: "On track to set venue record",
									tone: "success"
								})
							]
						})
					]
				})]
			})
		]
	});
}
function Bar2({ label, value, target }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between text-xs mb-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: value >= target ? "text-success" : "text-muted-foreground",
				children: [
					value,
					"% ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted-foreground",
						children: [
							"/ ",
							target,
							"%"
						]
					})
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
			value,
			className: "h-1.5"
		})]
	});
}
function Watch({ icon: Icon, title, hint, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-start gap-2.5 rounded-md border p-3 bg-card",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: `grid size-8 place-items-center rounded-md shrink-0 ${tone === "warn" ? "text-warning bg-warning/15" : tone === "brand" ? "text-brand bg-brand-soft" : tone === "success" ? "text-success bg-success/15" : "text-muted-foreground bg-muted"}`,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-sm font-medium",
				children: title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-[11px] text-muted-foreground",
				children: hint
			})]
		})]
	});
}
function QrGenerator({ codes, onAdd }) {
	const origin = typeof window !== "undefined" ? window.location.origin : "https://workspace.officeandco.co.za";
	const [form, setForm] = (0, import_react.useState)({
		title: "",
		client: "",
		date: "",
		attendees: 100,
		code: ""
	});
	const [preview, setPreview] = (0, import_react.useState)(null);
	const slug = (s) => s.toUpperCase().replace(/[^A-Z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 16);
	const create = () => {
		if (!form.title || !form.date) {
			toast.error("Title and date are required");
			return;
		}
		const code = form.code ? slug(form.code) : `${slug(form.title.split(" ").slice(0, 2).join(" "))}-${new Date(form.date).getFullYear().toString().slice(-2)}`;
		if (codes.some((c) => c.code === code)) {
			toast.error("Code already exists — choose another");
			return;
		}
		const c = {
			code,
			eventId: `US-${Date.now().toString().slice(-6)}`,
			title: form.title,
			date: form.date,
			client: form.client || "TBC",
			attendeesExpected: form.attendees,
			leadsCaptured: 0,
			conversionsToSales: 0,
			active: true
		};
		onAdd(c);
		setPreview(c);
		setForm({
			title: "",
			client: "",
			date: "",
			attendees: 100,
			code: ""
		});
		toast.success(`QR code ${code} generated`);
	};
	const qrUrl = (code, size = 220) => `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&margin=8&data=${encodeURIComponent(`${origin}/checkin/${code}`)}`;
	const copy = (t) => {
		navigator?.clipboard?.writeText(t);
		toast.success("Copied");
	};
	const mailto = (c) => {
		const url = `${origin}/checkin/${c.code}`;
		return `mailto:?subject=${encodeURIComponent(`Your check-in link — ${c.title}`)}&body=${encodeURIComponent(`Hi,\n\nOn arrival at Union Station, please scan the QR at the entrance or open this link to check in:\n\n${url}\n\nSee you at ${c.title} on ${c.date}.\n\n— Office & Co · Union Station`)}`;
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card-soft p-5 mb-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3 flex-wrap mb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
					className: "font-display font-semibold flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrCode, { className: "size-4 text-brand" }), " QR code generator"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Create unique check-in codes for every event — download for signage, copy for emails."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
					variant: "outline",
					className: "text-[10px]",
					children: [codes.length, " codes live"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid lg:grid-cols-[1fr_260px] gap-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid sm:grid-cols-2 gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5 sm:col-span-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Event title" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "e.g. Discovery Product Summit 2026",
								value: form.title,
								onChange: (e) => setForm({
									...form,
									title: e.target.value
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Client" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "Discovery Health",
								value: form.client,
								onChange: (e) => setForm({
									...form,
									client: e.target.value
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Date" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								value: form.date,
								onChange: (e) => setForm({
									...form,
									date: e.target.value
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Expected attendees" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								min: 1,
								value: form.attendees,
								onChange: (e) => setForm({
									...form,
									attendees: Number(e.target.value)
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, { children: ["Custom code ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] text-muted-foreground",
								children: "(optional)"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "Auto-generated if empty",
								value: form.code,
								onChange: (e) => setForm({
									...form,
									code: e.target.value
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "sm:col-span-2 flex gap-2 pt-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								onClick: create,
								className: "gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Generate QR"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: () => setForm({
									title: "",
									client: "",
									date: "",
									attendees: 100,
									code: ""
								}),
								children: "Reset"
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-lg border bg-muted/20 p-4 text-center",
					children: preview ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: qrUrl(preview.code, 200),
							alt: `QR for ${preview.title}`,
							width: 200,
							height: 200,
							className: "mx-auto rounded bg-white p-2"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 text-sm font-semibold truncate",
							children: preview.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] text-muted-foreground font-mono",
							children: preview.code
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 grid grid-cols-3 gap-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									size: "sm",
									variant: "outline",
									className: "h-8 text-[11px] gap-1",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: qrUrl(preview.code, 800),
										download: `qr-${preview.code}.png`,
										target: "_blank",
										rel: "noreferrer",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-3" }), "PNG"]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									variant: "outline",
									className: "h-8 text-[11px] gap-1",
									onClick: () => copy(`${origin}/checkin/${preview.code}`),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-3" }), "Link"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									size: "sm",
									variant: "outline",
									className: "h-8 text-[11px] gap-1",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: mailto(preview),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "size-3" }), "Email"]
									})
								})
							]
						})
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid place-items-center h-full py-10 text-xs text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrCode, { className: "size-8 mx-auto opacity-40 mb-2" }), "Preview appears here after generation"] })
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 border-t pt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs uppercase tracking-wider text-muted-foreground font-medium mb-3",
					children: "All active event codes — export for signage & emails"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid sm:grid-cols-2 lg:grid-cols-3 gap-3",
					children: codes.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg border bg-card p-3 flex gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: qrUrl(c.code, 120),
							alt: c.code,
							width: 80,
							height: 80,
							className: "rounded bg-white p-1.5 shrink-0"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs font-semibold truncate",
									children: c.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[10px] text-muted-foreground",
									children: [
										c.date,
										" · ",
										c.client
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[10px] font-mono text-muted-foreground truncate mt-0.5",
									children: c.code
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-2 flex flex-wrap gap-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											asChild: true,
											size: "icon",
											variant: "ghost",
											className: "size-6",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
												href: qrUrl(c.code, 800),
												download: `qr-${c.code}.png`,
												target: "_blank",
												rel: "noreferrer",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-3" })
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											size: "icon",
											variant: "ghost",
											className: "size-6",
											onClick: () => copy(`${origin}/checkin/${c.code}`),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-3" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											asChild: true,
											size: "icon",
											variant: "ghost",
											className: "size-6",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
												href: mailto(c),
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "size-3" })
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											size: "icon",
											variant: "ghost",
											className: "size-6",
											onClick: () => window.open(qrUrl(c.code, 800), "_blank")?.print(),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-3" })
										})
									]
								})
							]
						})]
					}, c.code))
				})]
			})
		]
	});
}
function ConversionAnalytics() {
	const totals = conversionByEvent.reduce((acc, r) => ({
		checkIns: acc.checkIns + r.checkIns,
		leads: acc.leads + r.leads,
		tours: acc.tours + r.tours,
		contracts: acc.contracts + r.contracts
	}), {
		checkIns: 0,
		leads: 0,
		tours: 0,
		contracts: 0
	});
	const leadRate = totals.checkIns ? Math.round(totals.leads / totals.checkIns * 100) : 0;
	const tourRate = totals.leads ? Math.round(totals.tours / totals.leads * 100) : 0;
	const contractRate = totals.tours ? Math.round(totals.contracts / totals.tours * 100) : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card-soft p-5 mb-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3 mb-4 flex-wrap",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
					className: "font-display font-semibold flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "size-4 text-brand" }), " Conversion analytics"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Check-in → Lead → Tour → Contract, by branch and event."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2 text-[11px]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
							variant: "outline",
							className: "text-brand border-brand/30",
							children: [
								"Lead rate ",
								leadRate,
								"%"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
							variant: "outline",
							className: "text-brand border-brand/30",
							children: [
								"Tour rate ",
								tourRate,
								"%"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
							variant: "outline",
							className: "text-success border-success/30",
							children: [
								"Contract rate ",
								contractRate,
								"%"
							]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 md:grid-cols-4 gap-3 mb-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FunnelStat, {
						label: "Check-ins",
						value: totals.checkIns,
						tone: "muted"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FunnelStat, {
						label: "Leads created",
						value: totals.leads,
						tone: "brand",
						pct: leadRate,
						of: "check-ins"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FunnelStat, {
						label: "Tour bookings",
						value: totals.tours,
						tone: "brand",
						pct: tourRate,
						of: "leads"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FunnelStat, {
						label: "Contracts signed",
						value: totals.contracts,
						tone: "success",
						pct: contractRate,
						of: "tours"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid lg:grid-cols-2 gap-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs uppercase tracking-wider text-muted-foreground font-medium mb-2",
					children: "By branch"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-64",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
						data: conversionByBranch,
						margin: {
							left: -10,
							right: 8,
							top: 8
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
								strokeDasharray: "3 3",
								stroke: "oklch(0.92 0.008 95)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
								dataKey: "branch",
								tick: {
									fontSize: 10,
									fill: "oklch(0.5 0.02 260)"
								},
								axisLine: false,
								tickLine: false
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
								tick: {
									fontSize: 11,
									fill: "oklch(0.5 0.02 260)"
								},
								axisLine: false,
								tickLine: false
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
								borderRadius: 10,
								border: "1px solid oklch(0.92 0.008 95)",
								fontSize: 12
							} }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, { wrapperStyle: { fontSize: 11 } }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
								dataKey: "checkIns",
								name: "Check-ins",
								fill: "oklch(0.86 0.02 260)",
								radius: [
									4,
									4,
									0,
									0
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
								dataKey: "leads",
								name: "Leads",
								fill: "oklch(0.55 0.14 260)",
								radius: [
									4,
									4,
									0,
									0
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
								dataKey: "tours",
								name: "Tours",
								fill: "oklch(0.5 0.08 195)",
								radius: [
									4,
									4,
									0,
									0
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
								dataKey: "contracts",
								name: "Contracts",
								fill: "oklch(0.55 0.14 155)",
								radius: [
									4,
									4,
									0,
									0
								]
							})
						]
					}) })
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs uppercase tracking-wider text-muted-foreground font-medium mb-2",
					children: "By event"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-lg border overflow-hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Event" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
							className: "text-right",
							children: "Check-ins"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
							className: "text-right",
							children: "Leads"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
							className: "text-right",
							children: "Tours"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
							className: "text-right",
							children: "Contracts"
						})
					] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: conversionByEvent.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm font-medium truncate max-w-[180px]",
							children: r.event
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[10px] text-muted-foreground",
							children: r.branch
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "text-right tabular-nums",
							children: formatInt(r.checkIns)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "text-right tabular-nums text-brand",
							children: formatInt(r.leads)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "text-right tabular-nums",
							children: r.tours
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "text-right tabular-nums text-success font-semibold",
							children: r.contracts
						})
					] }, r.eventCode)) })] })
				})] })]
			})
		]
	});
}
function FunnelStat({ label, value, tone, pct, of }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border bg-card p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-[11px] uppercase tracking-wider text-muted-foreground",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `font-display text-2xl font-semibold tabular-nums mt-1 ${tone === "brand" ? "text-brand" : tone === "success" ? "text-success" : "text-foreground"}`,
				children: formatInt(value)
			}),
			typeof pct === "number" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-[11px] text-muted-foreground mt-0.5",
				children: [
					pct,
					"% of ",
					of
				]
			})
		]
	});
}
//#endregion
export { UnionStationAdmin as component };
