import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { t as Badge } from "./badge-D1Dupn2y.mjs";
import { n as StatCard, t as PageHeader } from "./PageHeader-BGUb7ose.mjs";
import { C as Plus, H as Funnel, f as Sparkles } from "../_libs/lucide-react.mjs";
import { T as stages, _ as formatZAR, y as leads } from "./mock-B_SZb7O5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/crm-Du0YpaOp.js
var import_jsx_runtime = require_jsx_runtime();
function CRM() {
	const byStage = stages.map((s) => ({
		stage: s,
		items: leads.filter((l) => l.stage === s)
	}));
	const totalPipe = leads.reduce((s, l) => s + l.value, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-[1500px]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				eyebrow: "CRM & Sales Automation",
				title: "Pipeline",
				description: "Every enquiry, tour and proposal across all branches — with AI-scored qualification.",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						className: "gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Funnel, { className: "size-4" }), "Filter"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						className: "gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4" }), "AI follow-ups"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						className: "gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "New lead"]
					})
				] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 md:grid-cols-4 gap-4 mb-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Open pipeline",
						value: formatZAR(totalPipe),
						hint: `${leads.length} deals`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Win rate (30d)",
						value: "34%",
						delta: "▲ 4pts",
						accent: "success"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Avg cycle",
						value: "18 days",
						hint: "Tour → Won"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Tours this week",
						value: "27",
						delta: "+6 vs last",
						accent: "brand"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-3 min-w-max pb-4",
					children: byStage.map((col) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "w-72 shrink-0 rounded-xl bg-muted/40 p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between mb-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs font-semibold uppercase tracking-wider text-foreground/70",
								children: col.stage
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: "outline",
								className: "text-[10px]",
								children: col.items.length
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [col.items.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] text-muted-foreground italic p-2",
								children: "No deals"
							}), col.items.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "card-soft p-3 cursor-pointer hover:shadow-elevated transition-shadow",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-start justify-between mb-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-sm font-medium",
											children: l.company
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
											variant: "secondary",
											className: "text-[10px]",
											children: l.score
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-[11px] text-muted-foreground",
										children: [
											l.contact,
											" · ",
											l.source
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-2 flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-xs tabular-nums",
											children: l.value ? formatZAR(l.value) : "—"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[10px] text-muted-foreground",
											children: l.branch
										})]
									})
								]
							}, l.id))]
						})]
					}, col.stage))
				})
			})
		]
	});
}
//#endregion
export { CRM as component };
