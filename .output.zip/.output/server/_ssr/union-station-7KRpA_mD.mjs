import { i as __toESM } from "../_runtime.mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { t as Badge } from "./badge-D1Dupn2y.mjs";
import { n as StatCard, t as PageHeader } from "./PageHeader-BGUb7ose.mjs";
import { $ as CircleAlert, A as MapPin, G as ExternalLink, I as Landmark, J as Copy, Q as CircleCheck, U as FilePenLine, f as Sparkles, lt as CalendarHeart, r as Users, t as X, x as QrCode } from "../_libs/lucide-react.mjs";
import { A as unionStationRequests, _ as formatZAR, g as formatInt, j as unionStationVenue, p as eventAccessCodes } from "./mock-B_SZb7O5.mjs";
import { t as Label } from "./label-DBD1bRRP.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Checkbox } from "./checkbox-kt6FvQcE.mjs";
import { i as SelectItem, n as SelectContent, o as SelectTrigger, t as Select } from "./select-DG_6GgLn.mjs";
import { t as Textarea } from "./textarea-kko37XEX.mjs";
import { i as TabsTrigger, n as TabsContent, r as TabsList, t as Tabs } from "./tabs-CCJRliUM.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-C0WYWEQX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/union-station-7KRpA_mD.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STATUS_TONE = {
	Draft: "bg-muted text-foreground/70",
	Submitted: "bg-info/15 text-info border-info/20",
	"In Review": "bg-warning/15 text-warning border-warning/30",
	Quoted: "bg-brand/15 text-brand border-brand/30",
	Confirmed: "bg-success/15 text-success border-success/30",
	Invoiced: "bg-primary/15 text-primary border-primary/30",
	Completed: "bg-muted text-muted-foreground",
	Declined: "bg-destructive/15 text-destructive border-destructive/30"
};
var STATUS_FLOW = [
	"Draft",
	"Submitted",
	"In Review",
	"Quoted",
	"Confirmed",
	"Invoiced",
	"Completed"
];
function pricing(layout, attendees, hours, catering, av, afterHours) {
	const base = unionStationVenue.baseRatePerHour * Math.max(1, hours);
	const cater = unionStationVenue.cateringPerHead[catering] * attendees;
	const avTotal = av.reduce((s, a) => s + (unionStationVenue.avRates[a] ?? 0), 0);
	const sub = base + cater + avTotal;
	return Math.round(sub * (afterHours ? 1 + unionStationVenue.afterHoursSurchargePct : 1));
}
function UnionStation() {
	const [requests, setRequests] = (0, import_react.useState)(unionStationRequests);
	const [tab, setTab] = (0, import_react.useState)("request");
	const [form, setForm] = (0, import_react.useState)({
		client: "",
		contact: "",
		email: "",
		eventType: "Conference",
		date: "",
		start: "09:00",
		end: "17:00",
		attendees: 120,
		layout: "Theatre",
		catering: "Lunch",
		av: ["Pro AV + Streaming"],
		notes: ""
	});
	const hours = (0, import_react.useMemo)(() => {
		const [sh, sm] = form.start.split(":").map(Number);
		const [eh, em] = form.end.split(":").map(Number);
		return Math.max(1, eh + em / 60 - (sh + sm / 60));
	}, [form.start, form.end]);
	const afterHours = (0, import_react.useMemo)(() => Number(form.end.split(":")[0]) >= 19 || Number(form.start.split(":")[0]) < 7, [form.start, form.end]);
	const estimate = (0, import_react.useMemo)(() => pricing(form.layout, form.attendees, hours, form.catering, form.av, afterHours), [
		form,
		hours,
		afterHours
	]);
	const conflicts = (0, import_react.useMemo)(() => requests.filter((r) => r.date === form.date && [
		"Confirmed",
		"Quoted",
		"In Review"
	].includes(r.status)), [requests, form.date]);
	const submit = () => {
		if (!form.client || !form.date || !form.contact) {
			toast.error("Please complete client, contact and date.");
			return;
		}
		const id = `US-2026-${String(36 + requests.length).padStart(3, "0")}`;
		setRequests((prev) => [{
			id,
			client: form.client,
			contact: form.contact,
			email: form.email,
			eventType: form.eventType,
			date: form.date,
			start: form.start,
			end: form.end,
			attendees: form.attendees,
			layout: form.layout,
			catering: form.catering,
			av: form.av,
			notes: form.notes,
			status: "Submitted",
			estimate,
			depositPct: 30,
			contractSent: false,
			contractSigned: false,
			submittedBy: "You",
			submittedAt: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10)
		}, ...prev]);
		toast.success(`Request ${id} submitted — events team notified.`);
		setTab("approvals");
	};
	const updateStatus = (id, status) => {
		setRequests((prev) => prev.map((r) => r.id === id ? {
			...r,
			status
		} : r));
		toast.success(`${id} → ${status}`);
	};
	const stats = (0, import_react.useMemo)(() => {
		const confirmed = requests.filter((r) => r.status === "Confirmed" || r.status === "Invoiced").length;
		const pipeline = requests.filter((r) => [
			"Submitted",
			"In Review",
			"Quoted"
		].includes(r.status)).reduce((s, r) => s + r.estimate, 0);
		const guests = requests.filter((r) => r.status === "Confirmed").reduce((s, r) => s + r.attendees, 0);
		return {
			confirmed,
			pending: requests.length - confirmed,
			pipeline,
			guests
		};
	}, [requests]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-[1400px]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				eyebrow: "Union Station · Corporate Event Venue",
				title: "Premier corporate events — Johannesburg",
				description: "Africa's most-booked corporate venue. Submit a request, get a live quote, and route through approvals — all in one place.",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					size: "sm",
					children: "Download brochure"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					className: "gap-1.5",
					onClick: () => setTab("request"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarHeart, { className: "size-4" }), "New request"]
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "card-soft p-6 mb-6 relative overflow-hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 surface-grid opacity-50 pointer-events-none" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative grid md:grid-cols-[1.4fr_1fr] gap-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 text-xs text-muted-foreground mb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, { className: "size-3.5" }), " Heritage building · Johannesburg CBD"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl font-semibold mb-1.5",
							children: "Four halls. One unforgettable address."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-foreground/80 max-w-xl",
							children: "From a 24-seat boardroom to a 450-capacity gala dinner — Union Station is built for the most demanding corporate events: investor briefings, year-end galas, leadership summits and product launches."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 grid grid-cols-2 gap-2 max-w-md",
							children: unionStationVenue.halls.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-xs flex items-center gap-2 rounded-md border bg-card px-2.5 py-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3 text-brand" }), h]
							}, h))
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg border bg-card p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[11px] text-muted-foreground",
									children: "Max capacity"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-display text-2xl font-semibold mt-1",
									children: unionStationVenue.capacity
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[11px] text-muted-foreground mt-0.5 flex items-center gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-3" }), " Banquet / theatre"]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg border bg-card p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[11px] text-muted-foreground",
									children: "Base venue rate"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-display text-2xl font-semibold mt-1",
									children: formatZAR(unionStationVenue.baseRatePerHour)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[11px] text-muted-foreground mt-0.5",
									children: "per hour, exc. catering & AV"
								})
							]
						})]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 md:grid-cols-4 gap-4 mb-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Confirmed events",
						value: String(stats.confirmed),
						accent: "success"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "In pipeline",
						value: String(stats.pending),
						accent: "brand",
						hint: "awaiting approval"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Pipeline value",
						value: formatZAR(stats.pipeline),
						accent: "brand"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Confirmed guests",
						value: formatInt(stats.guests),
						hint: "next 90 days"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
				value: tab,
				onValueChange: setTab,
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "request",
							children: "New request"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "approvals",
							children: "Approvals queue"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "checkin",
							children: "Event check-in"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "calendar",
							children: "Calendar"
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "request",
						className: "space-y-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid lg:grid-cols-[1fr_360px] gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "card-soft p-6 space-y-5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid md:grid-cols-2 gap-4",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Client / Company" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													value: form.client,
													onChange: (e) => setForm({
														...form,
														client: e.target.value
													}),
													placeholder: "e.g. Investec Private Bank"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Event type" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
													value: form.eventType,
													onValueChange: (v) => setForm({
														...form,
														eventType: v
													}),
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: [
														"Conference",
														"Gala Dinner",
														"Product Launch",
														"Investor Briefing",
														"Leadership Offsite",
														"Workshop",
														"Awards Evening"
													].map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
														value: e,
														children: e
													}, e)) })]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Primary contact" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													value: form.contact,
													onChange: (e) => setForm({
														...form,
														contact: e.target.value
													}),
													placeholder: "Full name"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Email" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "email",
													value: form.email,
													onChange: (e) => setForm({
														...form,
														email: e.target.value
													}),
													placeholder: "name@company.com"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Date" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "date",
													value: form.date,
													onChange: (e) => setForm({
														...form,
														date: e.target.value
													})
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "grid grid-cols-2 gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "space-y-1.5",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Start" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
														type: "time",
														value: form.start,
														onChange: (e) => setForm({
															...form,
															start: e.target.value
														})
													})]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "space-y-1.5",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "End" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
														type: "time",
														value: form.end,
														onChange: (e) => setForm({
															...form,
															end: e.target.value
														})
													})]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Expected attendees" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "number",
													min: 1,
													max: unionStationVenue.capacity,
													value: form.attendees,
													onChange: (e) => setForm({
														...form,
														attendees: Number(e.target.value)
													})
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Layout" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
													value: form.layout,
													onValueChange: (v) => setForm({
														...form,
														layout: v
													}),
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: [
														"Theatre",
														"Banquet",
														"Cabaret",
														"Classroom",
														"Expo"
													].map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
														value: l,
														children: l
													}, l)) })]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Catering" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
													value: form.catering,
													onValueChange: (v) => setForm({
														...form,
														catering: v
													}),
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: Object.keys(unionStationVenue.cateringPerHead).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
														value: c,
														children: [
															c,
															" ",
															unionStationVenue.cateringPerHead[c] > 0 && `· ${formatZAR(unionStationVenue.cateringPerHead[c])}/head`
														]
													}, c)) })]
												})]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "AV & production add-ons" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "grid sm:grid-cols-2 gap-2",
											children: Object.entries(unionStationVenue.avRates).map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
												className: "flex items-center gap-2 rounded-md border bg-card px-3 py-2 cursor-pointer hover:bg-muted/30",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
														checked: form.av.includes(k),
														onCheckedChange: (c) => setForm({
															...form,
															av: c ? [...form.av, k] : form.av.filter((a) => a !== k)
														})
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-sm flex-1",
														children: k
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-xs text-muted-foreground tabular-nums",
														children: formatZAR(v)
													})
												]
											}, k))
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Notes for the events team" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
											rows: 3,
											value: form.notes,
											onChange: (e) => setForm({
												...form,
												notes: e.target.value
											}),
											placeholder: "Special requirements, dietary considerations, VIPs…"
										})]
									}),
									conflicts.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-start gap-2.5 rounded-md border border-warning/30 bg-warning/10 p-3 text-xs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "size-4 text-warning shrink-0 mt-px" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "font-medium text-warning",
											children: ["Possible conflict on ", form.date]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-foreground/80",
											children: conflicts.map((c) => `${c.client} (${c.status})`).join(" · ")
										})] })]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
								className: "card-soft p-6 h-fit sticky top-20",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[11px] uppercase tracking-wider text-brand font-medium mb-2",
										children: "Live quote"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-display text-3xl font-semibold tabular-nums",
										children: formatZAR(estimate)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs text-muted-foreground mt-1",
										children: "Estimate · exc. VAT"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-5 space-y-2 text-sm border-t pt-4",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
												label: `Venue · ${hours.toFixed(1)}h`,
												value: formatZAR(unionStationVenue.baseRatePerHour * hours)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
												label: `Catering · ${form.catering} × ${form.attendees}`,
												value: formatZAR(unionStationVenue.cateringPerHead[form.catering] * form.attendees)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
												label: `AV (${form.av.length})`,
												value: formatZAR(form.av.reduce((s, a) => s + (unionStationVenue.avRates[a] ?? 0), 0))
											}),
											afterHours && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
												label: `After-hours surcharge`,
												value: `+${Math.round(unionStationVenue.afterHoursSurchargePct * 100)}%`,
												highlight: true
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										className: "w-full mt-5 gap-1.5",
										onClick: submit,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4" }), "Submit request"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[11px] text-muted-foreground mt-3 text-center",
										children: "Events team responds within 4 business hours."
									})
								]
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
						value: "approvals",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "card-soft overflow-hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Request" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Date" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Guests" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Estimate" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Stage" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Contract" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
									className: "text-right",
									children: "Actions"
								})
							] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: requests.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-medium",
									children: r.client
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[11px] text-muted-foreground",
									children: [
										r.id,
										" · ",
										r.eventType,
										" · ",
										r.layout
									]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
									className: "text-sm",
									children: [r.date, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-[11px] text-muted-foreground",
										children: [
											r.start,
											"–",
											r.end
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "tabular-nums",
									children: r.attendees
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "tabular-nums",
									children: formatZAR(r.estimate)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "outline",
									className: STATUS_TONE[r.status],
									children: r.status
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 text-[11px]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: r.contractSent ? "text-success" : "text-muted-foreground",
											children: r.contractSent ? "Sent" : "—"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "opacity-30",
											children: "·"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: r.contractSigned ? "text-success" : "text-muted-foreground",
											children: r.contractSigned ? "Signed" : "Pending"
										})
									]
								}), r.depositPct > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[10px] text-muted-foreground",
									children: [
										"Deposit ",
										r.depositPct,
										"%"
									]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-right",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "inline-flex gap-1",
										children: [
											r.status === "Submitted" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												size: "sm",
												variant: "outline",
												className: "h-7",
												onClick: () => updateStatus(r.id, "In Review"),
												children: "Review"
											}),
											r.status === "In Review" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												size: "sm",
												className: "h-7 gap-1",
												onClick: () => updateStatus(r.id, "Quoted"),
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePenLine, { className: "size-3" }), "Send quote"]
											}),
											r.status === "Quoted" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												size: "sm",
												className: "h-7 gap-1",
												onClick: () => updateStatus(r.id, "Confirmed"),
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3" }), "Confirm"]
											}),
											r.status === "Confirmed" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												size: "sm",
												variant: "outline",
												className: "h-7",
												onClick: () => updateStatus(r.id, "Invoiced"),
												children: "Invoice"
											}),
											![
												"Declined",
												"Completed",
												"Invoiced"
											].includes(r.status) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												size: "sm",
												variant: "ghost",
												className: "h-7 text-destructive hover:text-destructive",
												onClick: () => updateStatus(r.id, "Declined"),
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3" })
											})
										]
									})
								})
							] }, r.id)) })] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 card-soft p-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs uppercase tracking-wider text-muted-foreground font-medium mb-3",
								children: "Approval workflow"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-1.5 text-[11px]",
								children: [
									STATUS_FLOW.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
											variant: "outline",
											className: STATUS_TONE[s],
											children: s
										}), i < STATUS_FLOW.length - 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground",
											children: "→"
										})]
									}, s)),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "ml-3 text-muted-foreground",
										children: "or"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: "outline",
										className: STATUS_TONE.Declined,
										children: "Declined"
									})
								]
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "checkin",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckInTab, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "calendar",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "card-soft p-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-medium mb-3",
								children: "Upcoming confirmed events"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-2",
								children: requests.filter((r) => r.status === "Confirmed" || r.status === "Invoiced").map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-[100px_1fr_auto] gap-3 items-center rounded-md border bg-card p-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-center",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-[10px] uppercase text-muted-foreground",
												children: r.date.slice(5, 7) === "07" ? "Jul" : r.date.slice(5, 7) === "08" ? "Aug" : "Sep"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "font-display text-xl font-semibold",
												children: r.date.slice(8)
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-sm font-medium",
											children: [
												r.client,
												" · ",
												r.eventType
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-[11px] text-muted-foreground",
											children: [
												r.start,
												"–",
												r.end,
												" · ",
												r.attendees,
												" guests · ",
												r.layout
											]
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
											variant: "outline",
											className: STATUS_TONE[r.status],
											children: r.status
										})
									]
								}, r.id))
							})]
						})
					})
				]
			})
		]
	});
}
function Row({ label, value, highlight }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: highlight ? "text-warning font-medium tabular-nums" : "tabular-nums",
			children: value
		})]
	});
}
function CheckInTab() {
	const origin = typeof window !== "undefined" ? window.location.origin : "https://workspace.officeandco.co.za";
	const copy = (txt) => {
		if (typeof navigator !== "undefined" && navigator.clipboard) navigator.clipboard.writeText(txt);
		toast.success("Copied to clipboard");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "card-soft p-5",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid size-10 place-items-center rounded-lg bg-brand-soft text-brand shrink-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrCode, { className: "size-5" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display font-semibold",
					children: "QR check-in for every Union Station event"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground mt-1 max-w-2xl",
					children: "Every attendee that steps into Union Station scans the QR at the entrance, captures their email, full name and (optionally) phone — instantly feeding the sales pipeline. Codes are unique per event."
				})] })]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid md:grid-cols-2 gap-4",
			children: eventAccessCodes.map((ev) => {
				const url = `${origin}/checkin/${ev.code}`;
				const qr = `https://api.qrserver.com/v1/create-qr-code/?size=220x220&margin=8&data=${encodeURIComponent(url)}`;
				const conv = ev.leadsCaptured > 0 ? Math.round(ev.conversionsToSales / ev.leadsCaptured * 100) : 0;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card-soft p-5 flex gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "shrink-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "rounded-md border bg-white p-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: qr,
								alt: `QR for ${ev.title}`,
								width: 120,
								height: 120,
								className: "block"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: "outline",
							className: `mt-2 w-full justify-center text-[10px] ${ev.active ? "text-success border-success/30" : "text-muted-foreground"}`,
							children: ev.active ? "Active" : "Scheduled"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1 min-w-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-semibold truncate",
								children: ev.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-[11px] text-muted-foreground",
								children: [
									ev.client,
									" · ",
									ev.date
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 grid grid-cols-3 gap-2 text-center",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										n: formatInt(ev.attendeesExpected),
										l: "Expected"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										n: formatInt(ev.leadsCaptured),
										l: "Captured",
										tone: "brand"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										n: `${conv}%`,
										l: "→ Sales",
										tone: "success"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex items-center gap-1.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
										className: "text-[11px] bg-muted px-2 py-1 rounded font-mono truncate flex-1",
										children: url
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "icon",
										variant: "ghost",
										className: "size-7",
										onClick: () => copy(url),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-3" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "icon",
										variant: "ghost",
										className: "size-7",
										asChild: true,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
											href: url,
											target: "_blank",
											rel: "noreferrer",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-3" })
										})
									})
								]
							})
						]
					})]
				}, ev.code);
			})
		})]
	});
}
function Stat({ n, l, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-md bg-muted/30 p-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: `font-display text-sm font-semibold tabular-nums ${tone === "brand" ? "text-brand" : tone === "success" ? "text-success" : "text-foreground"}`,
			children: n
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-[10px] text-muted-foreground",
			children: l
		})]
	});
}
//#endregion
export { UnionStation as component };
