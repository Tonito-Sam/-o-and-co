import { i as __toESM } from "../_runtime.mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { t as Badge } from "./badge-D1Dupn2y.mjs";
import { t as PageHeader } from "./PageHeader-BGUb7ose.mjs";
import { B as Hash, C as Plus, N as Lock, O as MessageSquarePlus, W as Eye, dt as Bell, ft as BellOff, h as ShieldCheck, ut as Building2, v as Send, y as Search } from "../_libs/lucide-react.mjs";
import { C as sampleThread, E as tenantManagers, n as ROLES, o as channelsCatalog, x as messages } from "./mock-B_SZb7O5.mjs";
import { t as Label } from "./label-DBD1bRRP.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as useRole } from "./role-context-CF0HzSPT.mjs";
import { t as Switch } from "./switch-Cn1w-cIH.mjs";
import { t as Textarea } from "./textarea-kko37XEX.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, s as DialogTrigger, t as Dialog } from "./dialog-DIo89e4g.mjs";
import { i as TooltipTrigger, n as TooltipContent, r as TooltipProvider, t as Tooltip } from "./tooltip-0uxD0LRD.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/messaging-DWTYIA6J.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STORAGE_SUBS = "woos.channelSubs";
var STORAGE_MUTES = "woos.channelMutes";
function readSet(key) {
	if (typeof window === "undefined") return /* @__PURE__ */ new Set();
	try {
		return new Set(JSON.parse(window.localStorage.getItem(key) ?? "[]"));
	} catch {
		return /* @__PURE__ */ new Set();
	}
}
function writeSet(key, s) {
	if (typeof window !== "undefined") window.localStorage.setItem(key, JSON.stringify([...s]));
}
function Messaging() {
	const { role } = useRole();
	const allowed = (0, import_react.useMemo)(() => channelsCatalog.filter((c) => c.allowedRoles.includes(role.id)), [role.id]);
	const [subs, setSubs] = (0, import_react.useState)(() => {
		const s = readSet(STORAGE_SUBS);
		if (s.size === 0) allowed.forEach((c) => s.add(c.name));
		return s;
	});
	const [mutes, setMutes] = (0, import_react.useState)(() => readSet(STORAGE_MUTES));
	const [active, setActive] = (0, import_react.useState)(allowed[0]?.name ?? "");
	const [browseOpen, setBrowseOpen] = (0, import_react.useState)(false);
	const [dmOpen, setDmOpen] = (0, import_react.useState)(false);
	const [draft, setDraft] = (0, import_react.useState)("");
	const subscribed = allowed.filter((c) => subs.has(c.name));
	const activeChannel = channelsCatalog.find((c) => c.name === active);
	const toggleSub = (name) => {
		const next = new Set(subs);
		if (next.has(name)) next.delete(name);
		else next.add(name);
		setSubs(next);
		writeSet(STORAGE_SUBS, next);
		toast.success(next.has(name) ? `Subscribed to #${name}` : `Unsubscribed from #${name}`);
	};
	const toggleMute = (name) => {
		const next = new Set(mutes);
		if (next.has(name)) next.delete(name);
		else next.add(name);
		setMutes(next);
		writeSet(STORAGE_MUTES, next);
	};
	const send = () => {
		if (!draft.trim()) return;
		toast.success(`Posted to #${active}`);
		setDraft("");
	};
	const channelIcon = (visibility) => visibility === "private" ? Lock : visibility === "restricted" ? ShieldCheck : Hash;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-[1400px]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: "Internal Communications",
			title: "Messaging",
			description: `Private channels and DMs for management, exec and ops — separate from the tenant community. Viewing as ${role.title}.`,
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
				open: browseOpen,
				onOpenChange: setBrowseOpen,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						className: "gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-3.5" }), "Browse channels"]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrowseChannels, {
					allowed,
					subs,
					onToggle: toggleSub
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
				open: dmOpen,
				onOpenChange: setDmOpen,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						className: "gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageSquarePlus, { className: "size-4" }), "New DM"]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NewDmDialog, { onClose: () => setDmOpen(false) })]
			})] })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid lg:grid-cols-[260px_1fr_280px] gap-4 h-[70vh] card-soft overflow-hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "border-r flex flex-col",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "p-3 border-b",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-2.5 top-1/2 size-3.5 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "Search…",
								className: "pl-8 h-8 text-sm bg-muted/40 border-transparent"
							})]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "px-2 py-2 overflow-y-auto flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between px-2 py-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[10px] uppercase tracking-wider text-muted-foreground font-medium",
									children: "Subscribed channels"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setBrowseOpen(true),
									className: "text-muted-foreground hover:text-foreground",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5" })
								})]
							}),
							subscribed.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "px-2 py-3 text-xs text-muted-foreground",
								children: "No subscriptions yet. Browse channels."
							}),
							subscribed.map((c) => {
								const Icon = channelIcon(c.visibility);
								const muted = mutes.has(c.name);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => setActive(c.name),
									className: `w-full group flex items-center justify-between px-2 py-1.5 rounded-md text-sm ${active === c.name ? "bg-brand-soft text-brand font-medium" : "hover:bg-muted/50"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex items-center gap-2 truncate",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-3.5 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: muted ? "opacity-60" : "",
											children: c.name
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tooltip, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipTrigger, {
										asChild: true,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											role: "button",
											tabIndex: 0,
											onClick: (e) => {
												e.stopPropagation();
												toggleMute(c.name);
											},
											onKeyDown: (e) => {
												if (e.key === "Enter") {
													e.stopPropagation();
													toggleMute(c.name);
												}
											},
											className: "opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer",
											children: muted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BellOff, { className: "size-3" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "size-3" })
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipContent, { children: muted ? "Unmute" : "Mute" })] }) })]
								}, c.name);
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[10px] uppercase tracking-wider text-muted-foreground font-medium px-2 py-1.5 mt-3",
								children: "Direct messages"
							}),
							messages.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								className: "w-full flex items-start gap-2 px-2 py-1.5 rounded-md text-sm hover:bg-muted/50 text-left",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid size-7 place-items-center rounded-full bg-muted text-[10px] font-medium shrink-0",
									children: m.from.split(" ").map((w) => w[0]).slice(0, 2).join("")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex-1 min-w-0 leading-tight",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `truncate text-xs ${m.unread ? "font-semibold" : ""}`,
											children: m.from
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] text-muted-foreground",
											children: m.time
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "truncate text-[11px] text-muted-foreground",
										children: m.preview
									})]
								})]
							}, m.id)),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between px-2 py-1.5 mt-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[10px] uppercase tracking-wider text-muted-foreground font-medium flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-3" }), "Tenant managers"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "outline",
									className: "text-[9px] h-4 px-1.5",
									children: tenantManagers.length
								})]
							}),
							tenantManagers.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								className: "w-full flex items-start gap-2 px-2 py-1.5 rounded-md text-sm hover:bg-muted/50 text-left",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative shrink-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "grid size-7 place-items-center rounded-full bg-brand-soft text-brand text-[10px] font-medium",
											children: t.initials
										}), t.online && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute -bottom-0.5 -right-0.5 size-2.5 rounded-full bg-success border-2 border-card" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex-1 min-w-0 leading-tight",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex justify-between",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: `truncate text-xs ${t.unread > 0 ? "font-semibold" : ""}`,
													children: t.name
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[10px] text-muted-foreground",
													children: t.lastTime
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "truncate text-[11px] text-muted-foreground",
												children: [
													t.tenant,
													" · ",
													t.branch
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "truncate text-[11px] text-muted-foreground/80",
												children: t.lastPreview
											})
										]
									}),
									t.unread > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										className: "text-[9px] h-4 px-1.5",
										children: t.unread
									})
								]
							}, t.id))
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "flex flex-col min-w-0",
					children: activeChannel ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "border-b px-5 py-3 flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 min-w-0",
								children: [
									(() => {
										return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(channelIcon(activeChannel.visibility), { className: "size-4 text-brand shrink-0" });
									})(),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-display font-semibold truncate",
										children: activeChannel.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
										variant: "outline",
										className: "text-[10px]",
										children: [
											activeChannel.visibility,
											" · ",
											activeChannel.members,
											" members"
										]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: subs.has(activeChannel.name) ? "outline" : "default",
								onClick: () => toggleSub(activeChannel.name),
								className: "h-7 text-[11px]",
								children: subs.has(activeChannel.name) ? "Unsubscribe" : "Subscribe"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex-1 overflow-y-auto px-5 py-4 space-y-4",
							children: [sampleThread.map((m, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid size-9 shrink-0 place-items-center rounded-full bg-brand-soft text-brand text-xs font-medium",
									children: m.initials
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex-1 min-w-0",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-baseline gap-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-sm font-semibold",
													children: m.from
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[11px] text-muted-foreground",
													children: m.role
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[11px] text-muted-foreground ml-auto",
													children: m.time
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm text-foreground/90 mt-0.5",
											children: m.text
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-1.5 flex items-center gap-2 text-[11px] text-muted-foreground",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-3" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "flex -space-x-1.5",
													children: m.seenBy.slice(0, 4).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "size-5 rounded-full border-2 border-card bg-muted grid place-items-center text-[9px] font-medium",
														children: s
													}, s))
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Seen by ", m.seenBy.length] })
											]
										})
									]
								})]
							}, i)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 my-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "flex-1 h-px bg-destructive/20" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] font-medium uppercase tracking-wider text-destructive",
										children: "New"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "flex-1 h-px bg-destructive/20" })
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "border-t p-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: draft,
									onChange: (e) => setDraft(e.target.value),
									onKeyDown: (e) => {
										if (e.key === "Enter" && !e.shiftKey) {
											e.preventDefault();
											send();
										}
									},
									placeholder: `Message #${active}`,
									className: "h-11 pr-12 bg-muted/30 border-transparent"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "icon",
									className: "absolute right-1.5 top-1.5 size-8",
									onClick: send,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-3.5" })
								})]
							})
						})
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex-1 grid place-items-center text-sm text-muted-foreground",
						children: "Select or subscribe to a channel"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
					className: "border-l p-4 hidden lg:block overflow-y-auto",
					children: activeChannel && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs uppercase tracking-wider text-muted-foreground font-medium mb-2",
							children: "About"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-foreground/80 mb-4",
							children: activeChannel.description
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs uppercase tracking-wider text-muted-foreground font-medium mb-2",
							children: "Access"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-1.5 mb-4",
							children: activeChannel.allowedRoles.map((rid) => {
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "outline",
									className: "text-[10px]",
									children: ROLES.find((x) => x.id === rid)?.title ?? rid
								}, rid);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-xs uppercase tracking-wider text-muted-foreground font-medium mb-2",
							children: [
								"Members (",
								activeChannel.members,
								")"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-2",
							children: [
								"Anthony Manas",
								"Samantha Naidoo",
								"Naledi Khoza",
								"Pieter v.d. Merwe",
								"Regie Mthembu",
								"Lerato Pillay"
							].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-6 rounded-full bg-muted grid place-items-center text-[10px]",
									children: n.split(" ").map((w) => w[0]).slice(0, 2).join("")
								}), n]
							}, n))
						})
					] })
				})
			]
		})]
	});
}
function BrowseChannels({ allowed, subs, onToggle }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
		className: "max-w-xl",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Browse channels" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Subscribe to channels available to your role. Restricted channels require role-based access." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-2 max-h-[60vh] overflow-y-auto",
			children: allowed.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between rounded-md border p-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-medium text-sm",
								children: ["#", c.name]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: "outline",
								className: "text-[10px]",
								children: c.visibility
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground mt-0.5",
							children: c.description
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-[11px] text-muted-foreground mt-1",
							children: [c.members, " members"]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
					checked: subs.has(c.name),
					onCheckedChange: () => onToggle(c.name)
				})]
			}, c.name))
		})]
	});
}
function NewDmDialog({ onClose }) {
	const [to, setTo] = (0, import_react.useState)([]);
	const [text, setText] = (0, import_react.useState)("");
	const send = () => {
		if (to.length === 0 || !text.trim()) {
			toast.error("Pick a recipient and write a message.");
			return;
		}
		toast.success(`DM sent to ${to.length} member${to.length > 1 ? "s" : ""}`);
		onClose();
	};
	const internal = ROLES.filter((r) => !["tenant-admin"].includes(r.id));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "New direct message" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Reach internal team members or tenant managers directly." })] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3 max-h-[60vh] overflow-y-auto",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-xs mb-1.5 block",
					children: "Office & Co team"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-1.5",
					children: internal.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setTo(to.includes(r.user) ? to.filter((x) => x !== r.user) : [...to, r.user]),
						className: `px-2.5 py-1 rounded-full border text-xs ${to.includes(r.user) ? "bg-brand-soft text-brand border-brand/30" : "hover:bg-muted/50"}`,
						children: r.user
					}, r.id))
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
					className: "text-xs mb-1.5 block flex items-center gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-3" }), "Tenant managers"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-1.5",
					children: tenantManagers.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => setTo(to.includes(t.name) ? to.filter((x) => x !== t.name) : [...to, t.name]),
						className: `px-2.5 py-1 rounded-full border text-xs ${to.includes(t.name) ? "bg-brand-soft text-brand border-brand/30" : "hover:bg-muted/50"}`,
						title: `${t.tenant} · ${t.branch}`,
						children: [
							t.name,
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-muted-foreground",
								children: ["· ", t.tenant]
							})
						]
					}, t.id))
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-xs mb-1.5 block",
					children: "Message"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					rows: 4,
					value: text,
					onChange: (e) => setText(e.target.value),
					placeholder: "Write a message…"
				})] })
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "outline",
			onClick: onClose,
			children: "Cancel"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			onClick: send,
			className: "gap-1.5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-3.5" }), "Send"]
		})] })
	] });
}
//#endregion
export { Messaging as component };
