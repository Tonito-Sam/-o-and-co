import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { t as Badge } from "./badge-D1Dupn2y.mjs";
import { n as StatCard, t as PageHeader } from "./PageHeader-BGUb7ose.mjs";
import { D as MessageSquare, V as Globe, dt as Bell, j as Mail, p as Smartphone } from "../_libs/lucide-react.mjs";
import { t as Switch } from "./switch-Cn1w-cIH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/notifications-BGlJ48o9.js
var import_jsx_runtime = require_jsx_runtime();
var channels = [
	{
		name: "Email",
		icon: Mail,
		on: true,
		sent: 12480
	},
	{
		name: "SMS",
		icon: MessageSquare,
		on: true,
		sent: 3210
	},
	{
		name: "WhatsApp",
		icon: MessageSquare,
		on: true,
		sent: 4840
	},
	{
		name: "Push",
		icon: Smartphone,
		on: true,
		sent: 18230
	},
	{
		name: "In-app",
		icon: Globe,
		on: true,
		sent: 28190
	}
];
var templates = [
	{
		name: "New invoice issued",
		channels: "Email · WhatsApp"
	},
	{
		name: "Booking confirmation",
		channels: "Email · Push"
	},
	{
		name: "Event reminder (24h)",
		channels: "Push · WhatsApp"
	},
	{
		name: "Community announcement",
		channels: "In-app · Push"
	},
	{
		name: "New team member joined",
		channels: "In-app"
	},
	{
		name: "Café promotion",
		channels: "Push"
	},
	{
		name: "Overdue invoice",
		channels: "Email · SMS · WhatsApp"
	}
];
function Notifications() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-[1200px]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				eyebrow: "Notifications Engine",
				title: "Channels & templates",
				description: "One engine, five channels — email, SMS, WhatsApp, push, in-app."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 md:grid-cols-4 gap-4 mb-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Sent (30d)",
						value: "66,940",
						accent: "brand"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Delivery rate",
						value: "99.2%",
						accent: "success"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Open rate",
						value: "48%"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Templates",
						value: "42"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid lg:grid-cols-[1fr_360px] gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card-soft p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display font-semibold mb-3",
						children: "Channels"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-3",
						children: channels.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between p-3 rounded-lg bg-muted/30",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid size-9 place-items-center rounded-md bg-brand-soft text-brand",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(c.icon, { className: "size-4" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "leading-tight",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-sm font-medium",
										children: c.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-[11px] text-muted-foreground",
										children: [c.sent.toLocaleString(), " sent (30d)"]
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, { defaultChecked: c.on })]
						}, c.name))
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card-soft p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
						className: "font-display font-semibold mb-3 flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "size-4" }), "Templates"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-2",
						children: templates.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between p-2.5 rounded-md hover:bg-muted/40 cursor-pointer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-medium",
								children: t.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] text-muted-foreground",
								children: t.channels
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: "outline",
								className: "text-[10px]",
								children: "Active"
							})]
						}, t.name))
					})]
				})]
			})
		]
	});
}
//#endregion
export { Notifications as component };
