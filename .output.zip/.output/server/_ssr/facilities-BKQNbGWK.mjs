import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { t as Badge } from "./badge-D1Dupn2y.mjs";
import { n as StatCard, t as PageHeader } from "./PageHeader-BGUb7ose.mjs";
import { C as Plus, q as DoorOpen } from "../_libs/lucide-react.mjs";
import { w as spaces } from "./mock-B_SZb7O5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/facilities-BKQNbGWK.js
var import_jsx_runtime = require_jsx_runtime();
var typeColor = {
	Boardroom: "bg-brand-soft text-brand",
	"Meeting Room": "bg-accent text-accent-foreground",
	"Podcast Studio": "bg-warning/20 text-warning",
	"Event Space": "bg-info/10 text-info",
	"Hot Desks": "bg-muted text-foreground/70",
	"Training Room": "bg-success/15 text-success"
};
function Facilities() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-[1400px]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				eyebrow: "Smart Facility Management",
				title: "Spaces",
				description: "Every boardroom, studio, desk and event space — live availability across the group.",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					className: "gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Register space"]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 md:grid-cols-4 gap-4 mb-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Total spaces",
						value: "412",
						hint: "Across 6 branches"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "In use now",
						value: "187",
						delta: "45% utilization",
						accent: "brand"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Booked next 2h",
						value: "64"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Avg utilization (wk)",
						value: "72%",
						delta: "▲ 5pts",
						accent: "success"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid md:grid-cols-2 xl:grid-cols-3 gap-4",
				children: spaces.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card-soft p-5 hover:shadow-elevated transition-shadow",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between mb-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `grid size-10 place-items-center rounded-lg ${typeColor[s.type] ?? "bg-muted"}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DoorOpen, { className: "size-5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
								variant: s.status === "Available" ? "default" : s.status === "In Use" ? "destructive" : "secondary",
								className: "text-[10px]",
								children: [s.status, s.until !== "—" && ` · until ${s.until}`]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-display text-lg font-semibold",
							children: s.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-xs text-muted-foreground mt-0.5",
							children: [
								s.type,
								" · capacity ",
								s.capacity
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 pt-3 border-t flex items-center justify-between text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-muted-foreground",
								children: [
									s.branch,
									" · Floor ",
									s.floor
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "sm",
								className: "h-7 text-xs",
								children: "Book"
							})]
						})
					]
				}, s.id))
			})
		]
	});
}
//#endregion
export { Facilities as component };
