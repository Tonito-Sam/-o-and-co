import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { t as Badge } from "./badge-D1Dupn2y.mjs";
import { n as StatCard, t as PageHeader } from "./PageHeader-BGUb7ose.mjs";
import { r as branches } from "./mock-B_SZb7O5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/bookings-DlYS-XgO.js
var import_jsx_runtime = require_jsx_runtime();
var slots = Array.from({ length: 10 }, (_, i) => `${8 + i}:00`);
var sample = [
	{
		branch: "Bryanston",
		room: "Atlas Boardroom",
		tenant: "Tundra Capital",
		start: 1,
		span: 2,
		kind: "Boardroom"
	},
	{
		branch: "Bryanston",
		room: "Karoo MR",
		tenant: "Northwind Legal",
		start: 2,
		span: 1,
		kind: "Meeting"
	},
	{
		branch: "Rosebank",
		room: "Podcast Studio B",
		tenant: "Mosaic Studio",
		start: 4,
		span: 2,
		kind: "Podcast"
	},
	{
		branch: "Bryanston",
		room: "The Loft",
		tenant: "Helix Ventures",
		start: 6,
		span: 3,
		kind: "Event"
	},
	{
		branch: "Kyalami",
		room: "Hot Desk Bank",
		tenant: "Ember & Co.",
		start: 0,
		span: 4,
		kind: "Desk"
	},
	{
		branch: "Kyalami",
		room: "Cedar Training Rm",
		tenant: "Quanta Labs",
		start: 5,
		span: 2,
		kind: "Training"
	}
];
function Bookings() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-[1500px]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				eyebrow: "Cross-Branch Bookings",
				title: "Today’s schedule",
				description: "A tenant in Bryanston can book a room in Cape Town in two clicks. Here’s every booking, everywhere, right now.",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					size: "sm",
					children: "Calendar"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					children: "New booking"
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 md:grid-cols-4 gap-4 mb-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Bookings today",
						value: "324",
						delta: "▲ 18 vs avg",
						accent: "brand"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Cross-branch",
						value: "47",
						hint: "14% of all"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Peak utilization",
						value: "11am",
						hint: "84% rooms in use"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Waiting lists",
						value: "6",
						accent: "warning"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "card-soft overflow-hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-[180px_1fr] border-b bg-muted/30",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "px-4 py-2.5 text-[11px] uppercase tracking-wider font-medium text-muted-foreground",
						children: "Branch / Room"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-10",
						children: slots.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "px-2 py-2.5 text-[11px] text-muted-foreground border-l",
							children: s
						}, s))
					})]
				}), branches.slice(0, 6).map((b) => {
					const rooms = sample.filter((s) => s.branch === b.name);
					if (rooms.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-[180px_1fr] border-b",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "px-4 py-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-medium",
								children: b.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] text-muted-foreground",
								children: "No bookings"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-10",
							children: slots.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "border-l h-12" }, s))
						})]
					}, b.id);
					return rooms.map((r, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-[180px_1fr] border-b",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "px-4 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-medium",
								children: idx === 0 ? b.name : ""
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] text-muted-foreground",
								children: r.room
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-10 relative h-12",
							children: [slots.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "border-l h-full",
								"data-i": i
							}, s)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "absolute top-1.5 bottom-1.5 rounded-md bg-brand/15 border border-brand/40 px-2 flex items-center text-[11px] text-foreground/85",
								style: {
									left: `${r.start / 10 * 100}%`,
									width: `${r.span / 10 * 100}%`
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "truncate font-medium",
									children: r.tenant
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "outline",
									className: "ml-auto text-[9px] bg-card",
									children: r.kind
								})]
							})]
						})]
					}, `${b.id}-${idx}`));
				})]
			})
		]
	});
}
//#endregion
export { Bookings as component };
