import { i as __toESM } from "../_runtime.mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { t as Badge } from "./badge-D1Dupn2y.mjs";
import { n as StatCard, t as PageHeader } from "./PageHeader-BGUb7ose.mjs";
import { S as revenueTrend, _ as formatZAR, r as branches } from "./mock-B_SZb7O5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/analytics-CgvekeTH.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var RechartsCharts = (0, import_react.lazy)(() => import("./RechartsCharts-DenN372w.mjs"));
var channels = [
	{
		name: "Workspace rental",
		value: 82e5
	},
	{
		name: "Bookings",
		value: 124e4
	},
	{
		name: "Café",
		value: 284e3
	},
	{
		name: "Marketplace",
		value: 41e4
	},
	{
		name: "Services",
		value: 186e3
	}
];
var colors = [
	"oklch(0.5 0.08 195)",
	"oklch(0.62 0.13 75)",
	"oklch(0.55 0.1 30)",
	"oklch(0.62 0.12 160)",
	"oklch(0.55 0.12 290)"
];
var radar = [
	{
		metric: "Occupancy",
		A: 87,
		B: 80
	},
	{
		metric: "Retention",
		A: 92,
		B: 88
	},
	{
		metric: "NPS",
		A: 72,
		B: 65
	},
	{
		metric: "Community",
		A: 78,
		B: 70
	},
	{
		metric: "Café",
		A: 81,
		B: 74
	},
	{
		metric: "Events",
		A: 68,
		B: 60
	}
];
function Analytics() {
	const charts = (0, import_react.useMemo)(() => ({
		channels,
		colors,
		radar,
		revenueTrend
	}), []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-[1400px]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				eyebrow: "Executive Intelligence",
				title: "Group analytics",
				description: "Forecasts, comparisons and predictive signals — the same view the board sees on Monday morning."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 md:grid-cols-4 gap-4 mb-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Annual revenue",
						value: formatZAR(142e6),
						delta: "▲ 18.4% YoY",
						accent: "success"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Forecast (Q4)",
						value: formatZAR(386e5),
						hint: "AI: 91% confidence",
						accent: "brand"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Renewal rate",
						value: "92%",
						delta: "▲ 3pts",
						accent: "success"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Churn risk",
						value: "3 tenants",
						delta: "AI flagged",
						accent: "warning"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
				fallback: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "card-soft p-5 text-sm text-muted-foreground",
					children: "Loading charts…"
				}),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RechartsCharts, { ...charts })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid lg:grid-cols-3 gap-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card-soft p-5 lg:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display font-semibold mb-3",
						children: "Branch leaderboard"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "divide-y",
						children: [...branches].sort((a, b) => b.revenue - a.revenue).map((b, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid size-8 place-items-center rounded-md bg-muted text-xs font-medium tabular-nums",
									children: i + 1
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "leading-tight",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-sm font-medium",
										children: b.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[11px] text-muted-foreground",
										children: b.city
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-6",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-right",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-sm tabular-nums",
										children: formatZAR(b.revenue)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[11px] text-muted-foreground",
										children: "MRR"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
									variant: "outline",
									className: "text-[10px] tabular-nums w-14 justify-center",
									children: [Math.round(b.occupancy * 100), "%"]
								})]
							})]
						}, b.id))
					})]
				})
			})
		]
	});
}
//#endregion
export { Analytics as component };
