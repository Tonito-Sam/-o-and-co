globalThis.__nitro_main__ = import.meta.url;
import { a as FastResponse, n as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/assets/ai-assistant-DzGjx_JD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"bc2-YkCBSkv/SKuacq553hqItQQYCrA\"",
		"mtime": "2026-07-02T18:55:33.585Z",
		"size": 3010,
		"path": "../public/assets/ai-assistant-DzGjx_JD.js"
	},
	"/assets/analytics-BpDf7_cp.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"cf5-wPAuYSBmNmCMMrzZ9IZBKCLXTQE\"",
		"mtime": "2026-07-02T18:55:33.597Z",
		"size": 3317,
		"path": "../public/assets/analytics-BpDf7_cp.js"
	},
	"/assets/auth.forgot-password-CRQCo9v1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"562-TGM6T+XvVJttwUzJFwgq07Rkdhg\"",
		"mtime": "2026-07-02T18:55:33.602Z",
		"size": 1378,
		"path": "../public/assets/auth.forgot-password-CRQCo9v1.js"
	},
	"/assets/auth.mfa-C2IPxel7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4b4-bZgAQUCb1QficEe/p4uUJ9AKVGY\"",
		"mtime": "2026-07-02T18:55:33.608Z",
		"size": 1204,
		"path": "../public/assets/auth.mfa-C2IPxel7.js"
	},
	"/assets/auth.reset-password-DYgoNz96.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"58e-hXisvu9iV6gkfbk4RKAGzfyIeE0\"",
		"mtime": "2026-07-02T18:55:33.620Z",
		"size": 1422,
		"path": "../public/assets/auth.reset-password-DYgoNz96.js"
	},
	"/assets/auth.sign-in-Cha21lqi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1390-CXUv+sFor0o6PYIWo3T8YXeJe+8\"",
		"mtime": "2026-07-02T18:55:33.631Z",
		"size": 5008,
		"path": "../public/assets/auth.sign-in-Cha21lqi.js"
	},
	"/assets/auth.sign-up-DP7meO-v.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a22-ll+FOoZOis+x3UWKof93ro7aGV4\"",
		"mtime": "2026-07-02T18:55:33.647Z",
		"size": 2594,
		"path": "../public/assets/auth.sign-up-DP7meO-v.js"
	},
	"/assets/auth.sso-BtWvykOc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"411-WSeJxKld4qcWp4wbjxhRKIML6LM\"",
		"mtime": "2026-07-02T18:55:33.650Z",
		"size": 1041,
		"path": "../public/assets/auth.sso-BtWvykOc.js"
	},
	"/assets/auth.verify-email-BEdEudI-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"542-pDWpzRSsUQDyburGz6hOOwaUBfY\"",
		"mtime": "2026-07-02T18:55:33.652Z",
		"size": 1346,
		"path": "../public/assets/auth.verify-email-BEdEudI-.js"
	},
	"/assets/AuthLayout-CDwaZtFR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9e2-D44UvvIo0mErOzvXi1yxmSmNzcA\"",
		"mtime": "2026-07-02T18:55:33.510Z",
		"size": 2530,
		"path": "../public/assets/AuthLayout-CDwaZtFR.js"
	},
	"/assets/bookings-zQW8vZhj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d63-bHfkiz3cPdtLDybMzaSFmqemLQU\"",
		"mtime": "2026-07-02T18:55:33.684Z",
		"size": 3427,
		"path": "../public/assets/bookings-zQW8vZhj.js"
	},
	"/assets/billing-hfKxZmK4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b77-mfkCAGnXs/KY2CP/jHafL1oUj9U\"",
		"mtime": "2026-07-02T18:55:33.670Z",
		"size": 2935,
		"path": "../public/assets/billing-hfKxZmK4.js"
	},
	"/assets/checkbox-BvTqHPWE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"30a-stIbC6O80eqz4H9UblQYZA4Adhk\"",
		"mtime": "2026-07-02T18:55:33.718Z",
		"size": 778,
		"path": "../public/assets/checkbox-BvTqHPWE.js"
	},
	"/assets/checkin._code-DKb3-pLm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1738-9Ww7Hx52mYMVI71PP5DXvdCPQzo\"",
		"mtime": "2026-07-02T18:55:33.724Z",
		"size": 5944,
		"path": "../public/assets/checkin._code-DKb3-pLm.js"
	},
	"/assets/cafe-CvhgvmPH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3f8b-zZbotklvXqkU87Eb9bRzNVFJu7A\"",
		"mtime": "2026-07-02T18:55:33.693Z",
		"size": 16267,
		"path": "../public/assets/cafe-CvhgvmPH.js"
	},
	"/assets/community-D7OTN2Yx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fd7-rK8vPhCP+NG6b1R8R4u81GA4Xhc\"",
		"mtime": "2026-07-02T18:55:33.734Z",
		"size": 4055,
		"path": "../public/assets/community-D7OTN2Yx.js"
	},
	"/assets/content-Do3PRIar.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a8d-s8s8n/8sBe6ez8zf8Jzj6VFDWFc\"",
		"mtime": "2026-07-02T18:55:33.742Z",
		"size": 2701,
		"path": "../public/assets/content-Do3PRIar.js"
	},
	"/assets/crm-BrIUAEQ3.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ad4-zDqbvnj9UQemYUT8/31GBPrSkd8\"",
		"mtime": "2026-07-02T18:55:33.749Z",
		"size": 2772,
		"path": "../public/assets/crm-BrIUAEQ3.js"
	},
	"/assets/dialog-CRjEYSmX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"871-RGDoVqiO5jv4kZ3Z7sP3bODYm58\"",
		"mtime": "2026-07-02T18:55:33.754Z",
		"size": 2161,
		"path": "../public/assets/dialog-CRjEYSmX.js"
	},
	"/assets/events-CRfZ5m1V.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"98a-n7XWZ7vil1JPpnJyqshbpar+GCg\"",
		"mtime": "2026-07-02T18:55:33.756Z",
		"size": 2442,
		"path": "../public/assets/events-CRfZ5m1V.js"
	},
	"/assets/facilities-X_HMAn2t.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"917-iBUVVdPhjLciNlva8Qg1uqfFiaI\"",
		"mtime": "2026-07-02T18:55:33.758Z",
		"size": 2327,
		"path": "../public/assets/facilities-X_HMAn2t.js"
	},
	"/assets/figtree-latin-400-normal-BD4aNku5.woff": {
		"type": "font/woff",
		"etag": "\"3abc-QN72Opx2/QqBdTVQSSd18mUquTc\"",
		"mtime": "2026-07-02T18:55:34.902Z",
		"size": 15036,
		"path": "../public/assets/figtree-latin-400-normal-BD4aNku5.woff"
	},
	"/assets/figtree-latin-400-normal-g7Dtegnw.woff2": {
		"type": "font/woff2",
		"etag": "\"2c78-bwwJusdNXqpjliMJowXAl/Bsbas\"",
		"mtime": "2026-07-02T18:55:34.903Z",
		"size": 11384,
		"path": "../public/assets/figtree-latin-400-normal-g7Dtegnw.woff2"
	},
	"/assets/figtree-latin-500-normal-BWnGEVsr.woff2": {
		"type": "font/woff2",
		"etag": "\"2ca8-+cnaOzVnRYdhRNAiMrIMX3P7A44\"",
		"mtime": "2026-07-02T18:55:34.903Z",
		"size": 11432,
		"path": "../public/assets/figtree-latin-500-normal-BWnGEVsr.woff2"
	},
	"/assets/figtree-latin-500-normal-B_yy1phn.woff": {
		"type": "font/woff",
		"etag": "\"3ac0-YCa875Sqe8BrQMP6wQewPPyE6zU\"",
		"mtime": "2026-07-02T18:55:34.904Z",
		"size": 15040,
		"path": "../public/assets/figtree-latin-500-normal-B_yy1phn.woff"
	},
	"/assets/figtree-latin-600-normal-BM_oTo4n.woff": {
		"type": "font/woff",
		"etag": "\"3b6c-mYTynQzeDajh2BFX7Pk9g/OCt2M\"",
		"mtime": "2026-07-02T18:55:34.908Z",
		"size": 15212,
		"path": "../public/assets/figtree-latin-600-normal-BM_oTo4n.woff"
	},
	"/assets/figtree-latin-600-normal-Cv_xCTDl.woff2": {
		"type": "font/woff2",
		"etag": "\"2d18-zcIOKGvUyJKQVl0IxpFpOVHy31E\"",
		"mtime": "2026-07-02T18:55:34.909Z",
		"size": 11544,
		"path": "../public/assets/figtree-latin-600-normal-Cv_xCTDl.woff2"
	},
	"/assets/figtree-latin-ext-400-normal-CXAzuTZb.woff2": {
		"type": "font/woff2",
		"etag": "\"182c-XzzkomiYzNc3xzCjO3rq/QZGmQE\"",
		"mtime": "2026-07-02T18:55:34.910Z",
		"size": 6188,
		"path": "../public/assets/figtree-latin-ext-400-normal-CXAzuTZb.woff2"
	},
	"/assets/figtree-latin-ext-400-normal-Gbh-3PTk.woff": {
		"type": "font/woff",
		"etag": "\"2090-wBPgF5qj/hBJGR0cf4n9MhOMHbs\"",
		"mtime": "2026-07-02T18:55:34.977Z",
		"size": 8336,
		"path": "../public/assets/figtree-latin-ext-400-normal-Gbh-3PTk.woff"
	},
	"/assets/figtree-latin-ext-500-normal-BOEJvrb_.woff": {
		"type": "font/woff",
		"etag": "\"2080-8Gd60yhMWkMGe+2EAF3VjoDdtBw\"",
		"mtime": "2026-07-02T18:55:34.979Z",
		"size": 8320,
		"path": "../public/assets/figtree-latin-ext-500-normal-BOEJvrb_.woff"
	},
	"/assets/figtree-latin-ext-500-normal-Du0rIuHj.woff2": {
		"type": "font/woff2",
		"etag": "\"180c-3wJmX8w1AXBV5mMcn0O5ajpulL4\"",
		"mtime": "2026-07-02T18:55:34.993Z",
		"size": 6156,
		"path": "../public/assets/figtree-latin-ext-500-normal-Du0rIuHj.woff2"
	},
	"/assets/figtree-latin-ext-600-normal-CQqsimlV.woff": {
		"type": "font/woff",
		"etag": "\"20a8-hLBeYSICmzFXGtjTDd1TCzxJiW4\"",
		"mtime": "2026-07-02T18:55:34.994Z",
		"size": 8360,
		"path": "../public/assets/figtree-latin-ext-600-normal-CQqsimlV.woff"
	},
	"/assets/figtree-latin-ext-600-normal-DJlfifZj.woff2": {
		"type": "font/woff2",
		"etag": "\"1860-t/zmKAgDoLM9oH+vT8xSljiox2I\"",
		"mtime": "2026-07-02T18:55:34.996Z",
		"size": 6240,
		"path": "../public/assets/figtree-latin-ext-600-normal-DJlfifZj.woff2"
	},
	"/assets/index-DBxFzUBu.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"15fa-Up+b8+G6bhAwAo9rqIhwKKJmQFw\"",
		"mtime": "2026-07-02T18:55:34.997Z",
		"size": 5626,
		"path": "../public/assets/index-DBxFzUBu.css"
	},
	"/assets/input-otp-CLQvyNIt.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"28ca-Q0i5aypNZSCjeI2d3PUpu6fHhd8\"",
		"mtime": "2026-07-02T18:55:33.762Z",
		"size": 10442,
		"path": "../public/assets/input-otp-CLQvyNIt.js"
	},
	"/assets/marketplace-DKG6Z4Qd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1782-5C1XppEHJZrC2Xiox42oaHxJ0fY\"",
		"mtime": "2026-07-02T18:55:33.767Z",
		"size": 6018,
		"path": "../public/assets/marketplace-DKG6Z4Qd.js"
	},
	"/assets/messaging-CQdpqJdI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3509-1N5ZE1vih68JRZBmTXOKtysAp14\"",
		"mtime": "2026-07-02T18:55:33.838Z",
		"size": 13577,
		"path": "../public/assets/messaging-CQdpqJdI.js"
	},
	"/assets/index-Di-u6AwM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5a7aa-WUZbsa/v3d4QEgl8Qyx+YQ+aGzw\"",
		"mtime": "2026-07-02T18:55:33.082Z",
		"size": 370602,
		"path": "../public/assets/index-Di-u6AwM.js"
	},
	"/assets/mobile-app-Bowb_JUq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f1a-ivLym4B/U8GsZyG8qfvzXHcxqJA\"",
		"mtime": "2026-07-02T18:55:33.863Z",
		"size": 3866,
		"path": "../public/assets/mobile-app-Bowb_JUq.js"
	},
	"/assets/notifications-BPJsXg8k.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b62-cPo2D6P7q6hkW3GEJDuY8sDCAaU\"",
		"mtime": "2026-07-02T18:55:33.870Z",
		"size": 2914,
		"path": "../public/assets/notifications-BPJsXg8k.js"
	},
	"/assets/OCO-Stacked-Logo-White-300px-HZXkK38G.png": {
		"type": "image/png",
		"etag": "\"2287-63BjiVN3Z0blSLd/EC9eXa96G1s\"",
		"mtime": "2026-07-02T18:55:34.901Z",
		"size": 8839,
		"path": "../public/assets/OCO-Stacked-Logo-White-300px-HZXkK38G.png"
	},
	"/assets/outfit-latin-400-normal-BGsTXAXT.woff2": {
		"type": "font/woff2",
		"etag": "\"36d0-aSuPZEAYPaKTR6fvqo0o7b6DVAE\"",
		"mtime": "2026-07-02T18:55:34.998Z",
		"size": 14032,
		"path": "../public/assets/outfit-latin-400-normal-BGsTXAXT.woff2"
	},
	"/assets/outfit-latin-400-normal-DMwTpYkH.woff": {
		"type": "font/woff",
		"etag": "\"4738-OQLPSmOkWVBXKt24vFt37LGJOQE\"",
		"mtime": "2026-07-02T18:55:34.999Z",
		"size": 18232,
		"path": "../public/assets/outfit-latin-400-normal-DMwTpYkH.woff"
	},
	"/assets/outfit-latin-500-normal-ClnHRwRh.woff": {
		"type": "font/woff",
		"etag": "\"4518-w03l9tbzPQvERzzPX0XbuVlJDwo\"",
		"mtime": "2026-07-02T18:55:35.001Z",
		"size": 17688,
		"path": "../public/assets/outfit-latin-500-normal-ClnHRwRh.woff"
	},
	"/assets/outfit-latin-500-normal-DKnIMDSk.woff2": {
		"type": "font/woff2",
		"etag": "\"34d8-VblYwuS4BTq3+cN4CQbLlgDlCEM\"",
		"mtime": "2026-07-02T18:55:35.003Z",
		"size": 13528,
		"path": "../public/assets/outfit-latin-500-normal-DKnIMDSk.woff2"
	},
	"/assets/outfit-latin-600-normal-B7SfZ07L.woff2": {
		"type": "font/woff2",
		"etag": "\"373c-lO2ZGP/Cb1/Gy6xyAy/s9XGtIMc\"",
		"mtime": "2026-07-02T18:55:35.004Z",
		"size": 14140,
		"path": "../public/assets/outfit-latin-600-normal-B7SfZ07L.woff2"
	},
	"/assets/outfit-latin-600-normal-BEfTtDA7.woff": {
		"type": "font/woff",
		"etag": "\"47ec-y5iGqL8nzhU0SHXTzfHrjZBJ9b4\"",
		"mtime": "2026-07-02T18:55:35.004Z",
		"size": 18412,
		"path": "../public/assets/outfit-latin-600-normal-BEfTtDA7.woff"
	},
	"/assets/outfit-latin-700-normal-Cu9v6i1X.woff2": {
		"type": "font/woff2",
		"etag": "\"36ec-kTCp+Plkm/MF4sH+u+F4cqfe4Zc\"",
		"mtime": "2026-07-02T18:55:35.011Z",
		"size": 14060,
		"path": "../public/assets/outfit-latin-700-normal-Cu9v6i1X.woff2"
	},
	"/assets/outfit-latin-700-normal-D4itBLBr.woff": {
		"type": "font/woff",
		"etag": "\"47a8-j/IzSkN1hqI5apw1tUYP/oVI00I\"",
		"mtime": "2026-07-02T18:55:35.024Z",
		"size": 18344,
		"path": "../public/assets/outfit-latin-700-normal-D4itBLBr.woff"
	},
	"/assets/outfit-latin-ext-400-normal-5tcqmc2S.woff2": {
		"type": "font/woff2",
		"etag": "\"18ec-BFjIu/hjYC+Hn18BG1D0Tm0l5xw\"",
		"mtime": "2026-07-02T18:55:35.025Z",
		"size": 6380,
		"path": "../public/assets/outfit-latin-ext-400-normal-5tcqmc2S.woff2"
	},
	"/assets/outfit-latin-ext-400-normal-DHm7mdGe.woff": {
		"type": "font/woff",
		"etag": "\"21c0-EnYpFrp7mweWwMlN9JBQ973Xm4Q\"",
		"mtime": "2026-07-02T18:55:35.026Z",
		"size": 8640,
		"path": "../public/assets/outfit-latin-ext-400-normal-DHm7mdGe.woff"
	},
	"/assets/outfit-latin-ext-500-normal-DrCvqoFD.woff": {
		"type": "font/woff",
		"etag": "\"212c-Cyo5cErsRCM5SY4eAfF9Kdn17E8\"",
		"mtime": "2026-07-02T18:55:35.029Z",
		"size": 8492,
		"path": "../public/assets/outfit-latin-ext-500-normal-DrCvqoFD.woff"
	},
	"/assets/outfit-latin-ext-500-normal-zeox_O30.woff2": {
		"type": "font/woff2",
		"etag": "\"1864-/+COtmjrR+mEmyW/k9C9VT/azKA\"",
		"mtime": "2026-07-02T18:55:35.039Z",
		"size": 6244,
		"path": "../public/assets/outfit-latin-ext-500-normal-zeox_O30.woff2"
	},
	"/assets/outfit-latin-ext-600-normal-B85nYjL1.woff2": {
		"type": "font/woff2",
		"etag": "\"1980-7v5HLJGwvvnRAVCdkrq5JwcliZA\"",
		"mtime": "2026-07-02T18:55:35.045Z",
		"size": 6528,
		"path": "../public/assets/outfit-latin-ext-600-normal-B85nYjL1.woff2"
	},
	"/assets/outfit-latin-ext-600-normal-CWJcPgd7.woff": {
		"type": "font/woff",
		"etag": "\"2230-N7Na8bpWhSB7OPFwAJqhFBnhZ0U\"",
		"mtime": "2026-07-02T18:55:35.059Z",
		"size": 8752,
		"path": "../public/assets/outfit-latin-ext-600-normal-CWJcPgd7.woff"
	},
	"/assets/outfit-latin-ext-700-normal-CI4iH74K.woff2": {
		"type": "font/woff2",
		"etag": "\"1954-v5ID+Y17cft0Fydr6B60fOoiLoA\"",
		"mtime": "2026-07-02T18:55:35.070Z",
		"size": 6484,
		"path": "../public/assets/outfit-latin-ext-700-normal-CI4iH74K.woff2"
	},
	"/assets/outfit-latin-ext-700-normal-fjS8-Gm7.woff": {
		"type": "font/woff",
		"etag": "\"2250-5MRCXutFxb0SmpKGZkw7JRFG2rw\"",
		"mtime": "2026-07-02T18:55:35.075Z",
		"size": 8784,
		"path": "../public/assets/outfit-latin-ext-700-normal-fjS8-Gm7.woff"
	},
	"/assets/PageHeader-GhD3zANC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4d2-Ok6rcwNA8D+Lsr/x5NRpWiCYddw\"",
		"mtime": "2026-07-02T18:55:33.565Z",
		"size": 1234,
		"path": "../public/assets/PageHeader-GhD3zANC.js"
	},
	"/assets/progress-C0jVGy59.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"226-7Shgyzv1qfzvgqVHfHihpLP5Q7s\"",
		"mtime": "2026-07-02T18:55:33.875Z",
		"size": 550,
		"path": "../public/assets/progress-C0jVGy59.js"
	},
	"/assets/RechartsCharts-DNvaR2kL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8d5-92xxpg5Q11WCCb7IbR4cDVgUccU\"",
		"mtime": "2026-07-02T18:55:33.573Z",
		"size": 2261,
		"path": "../public/assets/RechartsCharts-DNvaR2kL.js"
	},
	"/assets/rolldown-runtime-QTnfLwEv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2b6-wnqLLSlp3SaE+lbe74bKNe5Rpds\"",
		"mtime": "2026-07-02T18:55:33.876Z",
		"size": 694,
		"path": "../public/assets/rolldown-runtime-QTnfLwEv.js"
	},
	"/assets/routes-Bc06a6s-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2d41-rU+7k7LwOZ4egCTz7QA2ciIrWSQ\"",
		"mtime": "2026-07-02T18:55:33.877Z",
		"size": 11585,
		"path": "../public/assets/routes-Bc06a6s-.js"
	},
	"/assets/space-bryanston-PTa5Jxpf.jpg": {
		"type": "image/jpeg",
		"etag": "\"377ca-Hn9xbBm4pp9ez79EAbEUo8WpANk\"",
		"mtime": "2026-07-02T18:55:35.076Z",
		"size": 227274,
		"path": "../public/assets/space-bryanston-PTa5Jxpf.jpg"
	},
	"/assets/space-kyalami-BcQdajjm.jpg": {
		"type": "image/jpeg",
		"etag": "\"3a8c0-C75rkD45IGQYqZuhaFnFgQiWfaI\"",
		"mtime": "2026-07-02T18:55:35.077Z",
		"size": 239808,
		"path": "../public/assets/space-kyalami-BcQdajjm.jpg"
	},
	"/assets/settings.roles-rXczbsON.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d39-qG1R5ylOnaGj8JLke7ADUtSW/hU\"",
		"mtime": "2026-07-02T18:55:33.896Z",
		"size": 3385,
		"path": "../public/assets/settings.roles-rXczbsON.js"
	},
	"/assets/space-rosebank-DLGX1kDh.jpg": {
		"type": "image/jpeg",
		"etag": "\"27325-ndR43fM+i2XA8BwL6kzmq8uKwBk\"",
		"mtime": "2026-07-02T18:55:35.078Z",
		"size": 160549,
		"path": "../public/assets/space-rosebank-DLGX1kDh.jpg"
	},
	"/assets/space-union-station-Bc5NOarh.jpg": {
		"type": "image/jpeg",
		"etag": "\"5d30d-BOzytlcJ7E6IpQGBQsfqm9PruZ4\"",
		"mtime": "2026-07-02T18:55:35.079Z",
		"size": 381709,
		"path": "../public/assets/space-union-station-Bc5NOarh.jpg"
	},
	"/assets/styles-CeauSbbn.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"19066-PP2Yd72MWrsuyv0fgug+0lPEG6k\"",
		"mtime": "2026-07-02T18:55:35.080Z",
		"size": 102502,
		"path": "../public/assets/styles-CeauSbbn.css"
	},
	"/assets/support-DGh_G-W_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"895-XTERaKsMtOI/PP09o5sc1+1bEMA\"",
		"mtime": "2026-07-02T18:55:33.903Z",
		"size": 2197,
		"path": "../public/assets/support-DGh_G-W_.js"
	},
	"/assets/table-DlriWcqU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6c3-QdU++bae2ump2HtTV6dvd0GEwnw\"",
		"mtime": "2026-07-02T18:55:33.953Z",
		"size": 1731,
		"path": "../public/assets/table-DlriWcqU.js"
	},
	"/assets/tabs-0errczoo.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4ed-Ccs1/dxQokt+J1zVrd78AXXWe7s\"",
		"mtime": "2026-07-02T18:55:33.957Z",
		"size": 1261,
		"path": "../public/assets/tabs-0errczoo.js"
	},
	"/assets/tenants-CzRncb9K.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d20-4hkWUTqcRf3+wFEIgews5+2r3Fk\"",
		"mtime": "2026-07-02T18:55:33.960Z",
		"size": 3360,
		"path": "../public/assets/tenants-CzRncb9K.js"
	},
	"/assets/textarea-DJxo37gP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"25e-e2EdPENSONXFHcibBBQc7CC7hK8\"",
		"mtime": "2026-07-02T18:55:33.966Z",
		"size": 606,
		"path": "../public/assets/textarea-DJxo37gP.js"
	},
	"/assets/union-station-6GswNeb-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4aef-6chIzwr1MUcQsg0wXMCzHJt+yss\"",
		"mtime": "2026-07-02T18:55:33.969Z",
		"size": 19183,
		"path": "../public/assets/union-station-6GswNeb-.js"
	},
	"/assets/union-station-admin-ByQatdug.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"58b2-bDL7tsTYqIZlVBA8FhPxfHTiw4Y\"",
		"mtime": "2026-07-02T18:55:33.998Z",
		"size": 22706,
		"path": "../public/assets/union-station-admin-ByQatdug.js"
	},
	"/assets/vendor-d3-Pj3a_fBD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f3e3-pujNavmBWp+PsJPo8O+tQFDkkJk\"",
		"mtime": "2026-07-02T18:55:34.032Z",
		"size": 62435,
		"path": "../public/assets/vendor-d3-Pj3a_fBD.js"
	},
	"/assets/vendor-lucide-BhfUjMn8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5dc1-hVr24kgHSirr0VJSYbaNTL/mxgg\"",
		"mtime": "2026-07-02T18:55:34.107Z",
		"size": 24001,
		"path": "../public/assets/vendor-lucide-BhfUjMn8.js"
	},
	"/assets/vendor-radix-C940QKsh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"19941-wGM8BHZNo26T5xxtyZ/acUaOwzE\"",
		"mtime": "2026-07-02T18:55:34.192Z",
		"size": 104769,
		"path": "../public/assets/vendor-radix-C940QKsh.js"
	},
	"/assets/vendor-recharts-CN6l9Rrm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"59915-ieVa9VmzI6ImGQ4alSR1oAO7zO4\"",
		"mtime": "2026-07-02T18:55:34.298Z",
		"size": 366869,
		"path": "../public/assets/vendor-recharts-CN6l9Rrm.js"
	},
	"/assets/vendor-router-B48cdq4E.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"15a97-nG3+rZ81PvyxXf/cV08D+g2kGik\"",
		"mtime": "2026-07-02T18:55:34.791Z",
		"size": 88727,
		"path": "../public/assets/vendor-router-B48cdq4E.js"
	},
	"/assets/welcome-B00yoPxz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"51d1-dGTM5O8aG18/agpVCOP5eiBqKfs\"",
		"mtime": "2026-07-02T18:55:34.874Z",
		"size": 20945,
		"path": "../public/assets/welcome-B00yoPxz.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_WA9DBB = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_WA9DBB
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
