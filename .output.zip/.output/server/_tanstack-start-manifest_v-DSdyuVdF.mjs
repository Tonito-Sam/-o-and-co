//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DSdyuVdF.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/xampp/htdocs/o&co/src/routes/__root.tsx",
		children: [
			"/",
			"/ai-assistant",
			"/analytics",
			"/billing",
			"/bookings",
			"/cafe",
			"/community",
			"/content",
			"/crm",
			"/events",
			"/facilities",
			"/marketplace",
			"/messaging",
			"/mobile-app",
			"/notifications",
			"/support",
			"/tenants",
			"/union-station",
			"/union-station-admin",
			"/welcome",
			"/auth/forgot-password",
			"/auth/mfa",
			"/auth/reset-password",
			"/auth/sign-in",
			"/auth/sign-up",
			"/auth/sso",
			"/auth/verify-email",
			"/checkin/$code",
			"/settings/roles"
		],
		css: ["/p/o&co/assets/index-DBxFzUBu.css"],
		preloads: [
			"/p/o&co/assets/index-Di-u6AwM.js",
			"/p/o&co/assets/rolldown-runtime-QTnfLwEv.js",
			"/p/o&co/assets/vendor-lucide-BhfUjMn8.js",
			"/p/o&co/assets/vendor-radix-C940QKsh.js",
			"/p/o&co/assets/vendor-router-B48cdq4E.js",
			"/p/o&co/assets/vendor-recharts-CN6l9Rrm.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/p/o&co/assets/index-Di-u6AwM.js"
		} }]
	},
	"/": {
		filePath: "C:/xampp/htdocs/o&co/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/p/o&co/assets/routes-Bc06a6s-.js",
			"/p/o&co/assets/PageHeader-GhD3zANC.js",
			"/p/o&co/assets/progress-C0jVGy59.js"
		]
	},
	"/ai-assistant": {
		filePath: "C:/xampp/htdocs/o&co/src/routes/ai-assistant.tsx",
		children: void 0,
		preloads: ["/p/o&co/assets/ai-assistant-DzGjx_JD.js", "/p/o&co/assets/PageHeader-GhD3zANC.js"]
	},
	"/analytics": {
		filePath: "C:/xampp/htdocs/o&co/src/routes/analytics.tsx",
		children: void 0,
		preloads: ["/p/o&co/assets/analytics-BpDf7_cp.js", "/p/o&co/assets/PageHeader-GhD3zANC.js"]
	},
	"/billing": {
		filePath: "C:/xampp/htdocs/o&co/src/routes/billing.tsx",
		children: void 0,
		preloads: ["/p/o&co/assets/billing-hfKxZmK4.js", "/p/o&co/assets/PageHeader-GhD3zANC.js"]
	},
	"/bookings": {
		filePath: "C:/xampp/htdocs/o&co/src/routes/bookings.tsx",
		children: void 0,
		preloads: ["/p/o&co/assets/bookings-zQW8vZhj.js", "/p/o&co/assets/PageHeader-GhD3zANC.js"]
	},
	"/cafe": {
		filePath: "C:/xampp/htdocs/o&co/src/routes/cafe.tsx",
		children: void 0,
		preloads: [
			"/p/o&co/assets/cafe-CvhgvmPH.js",
			"/p/o&co/assets/PageHeader-GhD3zANC.js",
			"/p/o&co/assets/textarea-DJxo37gP.js",
			"/p/o&co/assets/tabs-0errczoo.js",
			"/p/o&co/assets/dialog-CRjEYSmX.js",
			"/p/o&co/assets/table-DlriWcqU.js"
		]
	},
	"/community": {
		filePath: "C:/xampp/htdocs/o&co/src/routes/community.tsx",
		children: void 0,
		preloads: [
			"/p/o&co/assets/community-D7OTN2Yx.js",
			"/p/o&co/assets/PageHeader-GhD3zANC.js",
			"/p/o&co/assets/textarea-DJxo37gP.js"
		]
	},
	"/content": {
		filePath: "C:/xampp/htdocs/o&co/src/routes/content.tsx",
		children: void 0,
		preloads: ["/p/o&co/assets/content-Do3PRIar.js", "/p/o&co/assets/PageHeader-GhD3zANC.js"]
	},
	"/crm": {
		filePath: "C:/xampp/htdocs/o&co/src/routes/crm.tsx",
		children: void 0,
		preloads: ["/p/o&co/assets/crm-BrIUAEQ3.js", "/p/o&co/assets/PageHeader-GhD3zANC.js"]
	},
	"/events": {
		filePath: "C:/xampp/htdocs/o&co/src/routes/events.tsx",
		children: void 0,
		preloads: [
			"/p/o&co/assets/events-CRfZ5m1V.js",
			"/p/o&co/assets/PageHeader-GhD3zANC.js",
			"/p/o&co/assets/progress-C0jVGy59.js"
		]
	},
	"/facilities": {
		filePath: "C:/xampp/htdocs/o&co/src/routes/facilities.tsx",
		children: void 0,
		preloads: ["/p/o&co/assets/facilities-X_HMAn2t.js", "/p/o&co/assets/PageHeader-GhD3zANC.js"]
	},
	"/marketplace": {
		filePath: "C:/xampp/htdocs/o&co/src/routes/marketplace.tsx",
		children: void 0,
		preloads: [
			"/p/o&co/assets/marketplace-DKG6Z4Qd.js",
			"/p/o&co/assets/PageHeader-GhD3zANC.js",
			"/p/o&co/assets/tabs-0errczoo.js",
			"/p/o&co/assets/table-DlriWcqU.js"
		]
	},
	"/messaging": {
		filePath: "C:/xampp/htdocs/o&co/src/routes/messaging.tsx",
		children: void 0,
		preloads: [
			"/p/o&co/assets/messaging-CQdpqJdI.js",
			"/p/o&co/assets/PageHeader-GhD3zANC.js",
			"/p/o&co/assets/textarea-DJxo37gP.js",
			"/p/o&co/assets/dialog-CRjEYSmX.js"
		]
	},
	"/mobile-app": {
		filePath: "C:/xampp/htdocs/o&co/src/routes/mobile-app.tsx",
		children: void 0,
		preloads: ["/p/o&co/assets/mobile-app-Bowb_JUq.js", "/p/o&co/assets/PageHeader-GhD3zANC.js"]
	},
	"/notifications": {
		filePath: "C:/xampp/htdocs/o&co/src/routes/notifications.tsx",
		children: void 0,
		preloads: ["/p/o&co/assets/notifications-BPJsXg8k.js", "/p/o&co/assets/PageHeader-GhD3zANC.js"]
	},
	"/support": {
		filePath: "C:/xampp/htdocs/o&co/src/routes/support.tsx",
		children: void 0,
		preloads: ["/p/o&co/assets/support-DGh_G-W_.js", "/p/o&co/assets/PageHeader-GhD3zANC.js"]
	},
	"/tenants": {
		filePath: "C:/xampp/htdocs/o&co/src/routes/tenants.tsx",
		children: void 0,
		preloads: ["/p/o&co/assets/tenants-CzRncb9K.js", "/p/o&co/assets/PageHeader-GhD3zANC.js"]
	},
	"/union-station": {
		filePath: "C:/xampp/htdocs/o&co/src/routes/union-station.tsx",
		children: void 0,
		preloads: [
			"/p/o&co/assets/union-station-6GswNeb-.js",
			"/p/o&co/assets/PageHeader-GhD3zANC.js",
			"/p/o&co/assets/checkbox-BvTqHPWE.js",
			"/p/o&co/assets/textarea-DJxo37gP.js",
			"/p/o&co/assets/tabs-0errczoo.js",
			"/p/o&co/assets/table-DlriWcqU.js"
		]
	},
	"/union-station-admin": {
		filePath: "C:/xampp/htdocs/o&co/src/routes/union-station-admin.tsx",
		children: void 0,
		preloads: [
			"/p/o&co/assets/union-station-admin-ByQatdug.js",
			"/p/o&co/assets/PageHeader-GhD3zANC.js",
			"/p/o&co/assets/progress-C0jVGy59.js",
			"/p/o&co/assets/table-DlriWcqU.js"
		]
	},
	"/welcome": {
		filePath: "C:/xampp/htdocs/o&co/src/routes/welcome.tsx",
		children: void 0,
		preloads: ["/p/o&co/assets/welcome-B00yoPxz.js"]
	},
	"/auth/forgot-password": {
		filePath: "C:/xampp/htdocs/o&co/src/routes/auth.forgot-password.tsx",
		children: void 0,
		preloads: ["/p/o&co/assets/auth.forgot-password-CRQCo9v1.js", "/p/o&co/assets/AuthLayout-CDwaZtFR.js"]
	},
	"/auth/mfa": {
		filePath: "C:/xampp/htdocs/o&co/src/routes/auth.mfa.tsx",
		children: void 0,
		preloads: [
			"/p/o&co/assets/auth.mfa-C2IPxel7.js",
			"/p/o&co/assets/AuthLayout-CDwaZtFR.js",
			"/p/o&co/assets/input-otp-CLQvyNIt.js"
		]
	},
	"/auth/reset-password": {
		filePath: "C:/xampp/htdocs/o&co/src/routes/auth.reset-password.tsx",
		children: void 0,
		preloads: ["/p/o&co/assets/auth.reset-password-DYgoNz96.js", "/p/o&co/assets/AuthLayout-CDwaZtFR.js"]
	},
	"/auth/sign-in": {
		filePath: "C:/xampp/htdocs/o&co/src/routes/auth.sign-in.tsx",
		children: void 0,
		preloads: [
			"/p/o&co/assets/auth.sign-in-Cha21lqi.js",
			"/p/o&co/assets/AuthLayout-CDwaZtFR.js",
			"/p/o&co/assets/checkbox-BvTqHPWE.js"
		]
	},
	"/auth/sign-up": {
		filePath: "C:/xampp/htdocs/o&co/src/routes/auth.sign-up.tsx",
		children: void 0,
		preloads: [
			"/p/o&co/assets/auth.sign-up-DP7meO-v.js",
			"/p/o&co/assets/AuthLayout-CDwaZtFR.js",
			"/p/o&co/assets/checkbox-BvTqHPWE.js",
			"/p/o&co/assets/progress-C0jVGy59.js"
		]
	},
	"/auth/sso": {
		filePath: "C:/xampp/htdocs/o&co/src/routes/auth.sso.tsx",
		children: void 0,
		preloads: ["/p/o&co/assets/auth.sso-BtWvykOc.js", "/p/o&co/assets/AuthLayout-CDwaZtFR.js"]
	},
	"/auth/verify-email": {
		filePath: "C:/xampp/htdocs/o&co/src/routes/auth.verify-email.tsx",
		children: void 0,
		preloads: [
			"/p/o&co/assets/auth.verify-email-BEdEudI-.js",
			"/p/o&co/assets/AuthLayout-CDwaZtFR.js",
			"/p/o&co/assets/input-otp-CLQvyNIt.js"
		]
	},
	"/checkin/$code": {
		filePath: "C:/xampp/htdocs/o&co/src/routes/checkin.$code.tsx",
		children: void 0,
		preloads: ["/p/o&co/assets/checkin._code-DKb3-pLm.js"]
	},
	"/settings/roles": {
		filePath: "C:/xampp/htdocs/o&co/src/routes/settings.roles.tsx",
		children: void 0,
		preloads: ["/p/o&co/assets/settings.roles-rXczbsON.js", "/p/o&co/assets/PageHeader-GhD3zANC.js"]
	}
} });
//#endregion
export { tsrStartManifest };
